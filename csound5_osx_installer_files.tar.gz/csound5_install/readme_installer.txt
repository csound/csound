This is the top-level of the installer structure. Here you
can find the package maker project files and the installation
directories where the files to be installed should be copied.

Place this at the top-level in your user directory, at the
same level as your csound5 build directory. Then from
the build directory, after all the files have been built,
run 

sudo sh macinstall-cp.sh

This should copy everything to their respective install
package directories.

Then you should copy any *.dylib dependencies from your
/usr/local/bin (say for fluid, libsndfile, fltk, etc...) to
./supportlibs/Package_contents/usr/local/lib

After this you are ready to build the installer. Just run
package maker and open the *.pkgm project files, build the
packages.

Then you can tar and gz (or make a .dmg) to package all these
files in an archive.

NB.: make sure all the directories/files inside Package_contents have
the right permissions and ownership, otherwise people's computers
can be messed up by the installation. Check they have pretty
much the same permissions as in your own computer (for Applications,
Library/Frameworks, usr/local/bin and usr/local/lib). This is OK
as I tar and gz the directory structure, but might be changed if
you ungzip and untar without using 'sudo'.

VL