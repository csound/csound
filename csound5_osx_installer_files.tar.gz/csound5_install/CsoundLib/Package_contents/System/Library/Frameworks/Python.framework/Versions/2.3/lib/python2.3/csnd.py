# This file was created automatically by SWIG 1.3.27.
# Don't modify this file, modify the SWIG interface instead.

import _csnd

# This file is compatible with both classic and new-style classes.
def _swig_setattr_nondynamic(self,class_type,name,value,static=1):
    if (name == "this"):
        if isinstance(value, class_type):
            self.__dict__[name] = value.this
            if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
            del value.thisown
            return
    method = class_type.__swig_setmethods__.get(name,None)
    if method: return method(self,value)
    if (not static) or hasattr(self,name) or (name == "thisown"):
        self.__dict__[name] = value
    else:
        raise AttributeError("You cannot add attributes to %s" % self)

def _swig_setattr(self,class_type,name,value):
    return _swig_setattr_nondynamic(self,class_type,name,value,0)

def _swig_getattr(self,class_type,name):
    method = class_type.__swig_getmethods__.get(name,None)
    if method: return method(self)
    raise AttributeError,name

import types
try:
    _object = types.ObjectType
    _newclass = 1
except AttributeError:
    class _object : pass
    _newclass = 0
del types



new_intp = _csnd.new_intp

delete_intp = _csnd.delete_intp

intp_getitem = _csnd.intp_getitem

intp_setitem = _csnd.intp_setitem

new_floatp = _csnd.new_floatp

delete_floatp = _csnd.delete_floatp

floatp_getitem = _csnd.floatp_getitem

floatp_setitem = _csnd.floatp_setitem

new_doublep = _csnd.new_doublep

delete_doublep = _csnd.delete_doublep

doublep_getitem = _csnd.doublep_getitem

doublep_setitem = _csnd.doublep_setitem
class intArray(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, intArray, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, intArray, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ intArray instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        _swig_setattr(self, intArray, 'this', _csnd.new_intArray(*args))
        _swig_setattr(self, intArray, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_intArray):
        try:
            if self.thisown: destroy(self)
        except: pass

    def __getitem__(*args): return _csnd.intArray___getitem__(*args)
    def __setitem__(*args): return _csnd.intArray___setitem__(*args)
    def cast(*args): return _csnd.intArray_cast(*args)
    __swig_getmethods__["frompointer"] = lambda x: _csnd.intArray_frompointer
    if _newclass:frompointer = staticmethod(_csnd.intArray_frompointer)

class intArrayPtr(intArray):
    def __init__(self, this):
        _swig_setattr(self, intArray, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, intArray, 'thisown', 0)
        self.__class__ = intArray
_csnd.intArray_swigregister(intArrayPtr)

intArray_frompointer = _csnd.intArray_frompointer

class floatArray(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, floatArray, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, floatArray, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ floatArray instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        _swig_setattr(self, floatArray, 'this', _csnd.new_floatArray(*args))
        _swig_setattr(self, floatArray, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_floatArray):
        try:
            if self.thisown: destroy(self)
        except: pass

    def __getitem__(*args): return _csnd.floatArray___getitem__(*args)
    def __setitem__(*args): return _csnd.floatArray___setitem__(*args)
    def cast(*args): return _csnd.floatArray_cast(*args)
    __swig_getmethods__["frompointer"] = lambda x: _csnd.floatArray_frompointer
    if _newclass:frompointer = staticmethod(_csnd.floatArray_frompointer)

class floatArrayPtr(floatArray):
    def __init__(self, this):
        _swig_setattr(self, floatArray, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, floatArray, 'thisown', 0)
        self.__class__ = floatArray
_csnd.floatArray_swigregister(floatArrayPtr)

floatArray_frompointer = _csnd.floatArray_frompointer

class doubleArray(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, doubleArray, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, doubleArray, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ doubleArray instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        _swig_setattr(self, doubleArray, 'this', _csnd.new_doubleArray(*args))
        _swig_setattr(self, doubleArray, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_doubleArray):
        try:
            if self.thisown: destroy(self)
        except: pass

    def __getitem__(*args): return _csnd.doubleArray___getitem__(*args)
    def __setitem__(*args): return _csnd.doubleArray___setitem__(*args)
    def cast(*args): return _csnd.doubleArray_cast(*args)
    __swig_getmethods__["frompointer"] = lambda x: _csnd.doubleArray_frompointer
    if _newclass:frompointer = staticmethod(_csnd.doubleArray_frompointer)

class doubleArrayPtr(doubleArray):
    def __init__(self, this):
        _swig_setattr(self, doubleArray, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, doubleArray, 'thisown', 0)
        self.__class__ = doubleArray
_csnd.doubleArray_swigregister(doubleArrayPtr)

doubleArray_frompointer = _csnd.doubleArray_frompointer

CSOUND_SUCCESS = _csnd.CSOUND_SUCCESS
CSOUND_ERROR = _csnd.CSOUND_ERROR
CSOUND_INITIALIZATION = _csnd.CSOUND_INITIALIZATION
CSOUND_PERFORMANCE = _csnd.CSOUND_PERFORMANCE
CSOUND_MEMORY = _csnd.CSOUND_MEMORY
CSOUND_SIGNAL = _csnd.CSOUND_SIGNAL
CSOUND_EXITJMP_SUCCESS = _csnd.CSOUND_EXITJMP_SUCCESS
CSOUNDINIT_NO_SIGNAL_HANDLER = _csnd.CSOUNDINIT_NO_SIGNAL_HANDLER
CSOUNDINIT_NO_ATEXIT = _csnd.CSOUNDINIT_NO_ATEXIT
CSOUND_CONTROL_CHANNEL = _csnd.CSOUND_CONTROL_CHANNEL
CSOUND_AUDIO_CHANNEL = _csnd.CSOUND_AUDIO_CHANNEL
CSOUND_STRING_CHANNEL = _csnd.CSOUND_STRING_CHANNEL
CSOUND_CHANNEL_TYPE_MASK = _csnd.CSOUND_CHANNEL_TYPE_MASK
CSOUND_INPUT_CHANNEL = _csnd.CSOUND_INPUT_CHANNEL
CSOUND_OUTPUT_CHANNEL = _csnd.CSOUND_OUTPUT_CHANNEL
CSOUND_CONTROL_CHANNEL_INT = _csnd.CSOUND_CONTROL_CHANNEL_INT
CSOUND_CONTROL_CHANNEL_LIN = _csnd.CSOUND_CONTROL_CHANNEL_LIN
CSOUND_CONTROL_CHANNEL_EXP = _csnd.CSOUND_CONTROL_CHANNEL_EXP
CSOUND_CALLBACK_KBD_EVENT = _csnd.CSOUND_CALLBACK_KBD_EVENT
CSOUND_CALLBACK_KBD_TEXT = _csnd.CSOUND_CALLBACK_KBD_TEXT
class csRtAudioParams(_object):
    """Proxy of C++ csRtAudioParams class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, csRtAudioParams, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, csRtAudioParams, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ csRtAudioParams instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["devName"] = _csnd.csRtAudioParams_devName_set
    __swig_getmethods__["devName"] = _csnd.csRtAudioParams_devName_get
    if _newclass:devName = property(_csnd.csRtAudioParams_devName_get, _csnd.csRtAudioParams_devName_set)
    __swig_setmethods__["devNum"] = _csnd.csRtAudioParams_devNum_set
    __swig_getmethods__["devNum"] = _csnd.csRtAudioParams_devNum_get
    if _newclass:devNum = property(_csnd.csRtAudioParams_devNum_get, _csnd.csRtAudioParams_devNum_set)
    __swig_setmethods__["bufSamp_SW"] = _csnd.csRtAudioParams_bufSamp_SW_set
    __swig_getmethods__["bufSamp_SW"] = _csnd.csRtAudioParams_bufSamp_SW_get
    if _newclass:bufSamp_SW = property(_csnd.csRtAudioParams_bufSamp_SW_get, _csnd.csRtAudioParams_bufSamp_SW_set)
    __swig_setmethods__["bufSamp_HW"] = _csnd.csRtAudioParams_bufSamp_HW_set
    __swig_getmethods__["bufSamp_HW"] = _csnd.csRtAudioParams_bufSamp_HW_get
    if _newclass:bufSamp_HW = property(_csnd.csRtAudioParams_bufSamp_HW_get, _csnd.csRtAudioParams_bufSamp_HW_set)
    __swig_setmethods__["nChannels"] = _csnd.csRtAudioParams_nChannels_set
    __swig_getmethods__["nChannels"] = _csnd.csRtAudioParams_nChannels_get
    if _newclass:nChannels = property(_csnd.csRtAudioParams_nChannels_get, _csnd.csRtAudioParams_nChannels_set)
    __swig_setmethods__["sampleFormat"] = _csnd.csRtAudioParams_sampleFormat_set
    __swig_getmethods__["sampleFormat"] = _csnd.csRtAudioParams_sampleFormat_get
    if _newclass:sampleFormat = property(_csnd.csRtAudioParams_sampleFormat_get, _csnd.csRtAudioParams_sampleFormat_set)
    __swig_setmethods__["sampleRate"] = _csnd.csRtAudioParams_sampleRate_set
    __swig_getmethods__["sampleRate"] = _csnd.csRtAudioParams_sampleRate_get
    if _newclass:sampleRate = property(_csnd.csRtAudioParams_sampleRate_get, _csnd.csRtAudioParams_sampleRate_set)
    def __init__(self, *args):
        """__init__(self) -> csRtAudioParams"""
        _swig_setattr(self, csRtAudioParams, 'this', _csnd.new_csRtAudioParams(*args))
        _swig_setattr(self, csRtAudioParams, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_csRtAudioParams):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class csRtAudioParamsPtr(csRtAudioParams):
    def __init__(self, this):
        _swig_setattr(self, csRtAudioParams, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, csRtAudioParams, 'thisown', 0)
        self.__class__ = csRtAudioParams
_csnd.csRtAudioParams_swigregister(csRtAudioParamsPtr)

class RTCLOCK(_object):
    """Proxy of C++ RTCLOCK class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, RTCLOCK, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, RTCLOCK, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ RTCLOCK instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["starttime_real"] = _csnd.RTCLOCK_starttime_real_set
    __swig_getmethods__["starttime_real"] = _csnd.RTCLOCK_starttime_real_get
    if _newclass:starttime_real = property(_csnd.RTCLOCK_starttime_real_get, _csnd.RTCLOCK_starttime_real_set)
    __swig_setmethods__["starttime_CPU"] = _csnd.RTCLOCK_starttime_CPU_set
    __swig_getmethods__["starttime_CPU"] = _csnd.RTCLOCK_starttime_CPU_get
    if _newclass:starttime_CPU = property(_csnd.RTCLOCK_starttime_CPU_get, _csnd.RTCLOCK_starttime_CPU_set)
    def __init__(self, *args):
        """__init__(self) -> RTCLOCK"""
        _swig_setattr(self, RTCLOCK, 'this', _csnd.new_RTCLOCK(*args))
        _swig_setattr(self, RTCLOCK, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_RTCLOCK):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class RTCLOCKPtr(RTCLOCK):
    def __init__(self, this):
        _swig_setattr(self, RTCLOCK, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, RTCLOCK, 'thisown', 0)
        self.__class__ = RTCLOCK
_csnd.RTCLOCK_swigregister(RTCLOCKPtr)

class opcodeListEntry(_object):
    """Proxy of C++ opcodeListEntry class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, opcodeListEntry, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, opcodeListEntry, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ opcodeListEntry instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["opname"] = _csnd.opcodeListEntry_opname_set
    __swig_getmethods__["opname"] = _csnd.opcodeListEntry_opname_get
    if _newclass:opname = property(_csnd.opcodeListEntry_opname_get, _csnd.opcodeListEntry_opname_set)
    __swig_setmethods__["outypes"] = _csnd.opcodeListEntry_outypes_set
    __swig_getmethods__["outypes"] = _csnd.opcodeListEntry_outypes_get
    if _newclass:outypes = property(_csnd.opcodeListEntry_outypes_get, _csnd.opcodeListEntry_outypes_set)
    __swig_setmethods__["intypes"] = _csnd.opcodeListEntry_intypes_set
    __swig_getmethods__["intypes"] = _csnd.opcodeListEntry_intypes_get
    if _newclass:intypes = property(_csnd.opcodeListEntry_intypes_get, _csnd.opcodeListEntry_intypes_set)
    def __init__(self, *args):
        """__init__(self) -> opcodeListEntry"""
        _swig_setattr(self, opcodeListEntry, 'this', _csnd.new_opcodeListEntry(*args))
        _swig_setattr(self, opcodeListEntry, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_opcodeListEntry):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class opcodeListEntryPtr(opcodeListEntry):
    def __init__(self, this):
        _swig_setattr(self, opcodeListEntry, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, opcodeListEntry, 'thisown', 0)
        self.__class__ = opcodeListEntry
_csnd.opcodeListEntry_swigregister(opcodeListEntryPtr)

class CsoundRandMTState(_object):
    """Proxy of C++ CsoundRandMTState class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundRandMTState, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundRandMTState, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundRandMTState instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["mti"] = _csnd.CsoundRandMTState_mti_set
    __swig_getmethods__["mti"] = _csnd.CsoundRandMTState_mti_get
    if _newclass:mti = property(_csnd.CsoundRandMTState_mti_get, _csnd.CsoundRandMTState_mti_set)
    __swig_setmethods__["mt"] = _csnd.CsoundRandMTState_mt_set
    __swig_getmethods__["mt"] = _csnd.CsoundRandMTState_mt_get
    if _newclass:mt = property(_csnd.CsoundRandMTState_mt_get, _csnd.CsoundRandMTState_mt_set)
    def __init__(self, *args):
        """__init__(self) -> CsoundRandMTState"""
        _swig_setattr(self, CsoundRandMTState, 'this', _csnd.new_CsoundRandMTState(*args))
        _swig_setattr(self, CsoundRandMTState, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundRandMTState):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundRandMTStatePtr(CsoundRandMTState):
    def __init__(self, this):
        _swig_setattr(self, CsoundRandMTState, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundRandMTState, 'thisown', 0)
        self.__class__ = CsoundRandMTState
_csnd.CsoundRandMTState_swigregister(CsoundRandMTStatePtr)

class CsoundChannelListEntry(_object):
    """Proxy of C++ CsoundChannelListEntry class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundChannelListEntry, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundChannelListEntry, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundChannelListEntry instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["name"] = _csnd.CsoundChannelListEntry_name_set
    __swig_getmethods__["name"] = _csnd.CsoundChannelListEntry_name_get
    if _newclass:name = property(_csnd.CsoundChannelListEntry_name_get, _csnd.CsoundChannelListEntry_name_set)
    __swig_setmethods__["type"] = _csnd.CsoundChannelListEntry_type_set
    __swig_getmethods__["type"] = _csnd.CsoundChannelListEntry_type_get
    if _newclass:type = property(_csnd.CsoundChannelListEntry_type_get, _csnd.CsoundChannelListEntry_type_set)
    def __init__(self, *args):
        """__init__(self) -> CsoundChannelListEntry"""
        _swig_setattr(self, CsoundChannelListEntry, 'this', _csnd.new_CsoundChannelListEntry(*args))
        _swig_setattr(self, CsoundChannelListEntry, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundChannelListEntry):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundChannelListEntryPtr(CsoundChannelListEntry):
    def __init__(self, this):
        _swig_setattr(self, CsoundChannelListEntry, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundChannelListEntry, 'thisown', 0)
        self.__class__ = CsoundChannelListEntry
_csnd.CsoundChannelListEntry_swigregister(CsoundChannelListEntryPtr)

class PVSDATEXT(_object):
    """Proxy of C++ PVSDATEXT class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, PVSDATEXT, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, PVSDATEXT, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ PVSDATEXT instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["N"] = _csnd.PVSDATEXT_N_set
    __swig_getmethods__["N"] = _csnd.PVSDATEXT_N_get
    if _newclass:N = property(_csnd.PVSDATEXT_N_get, _csnd.PVSDATEXT_N_set)
    __swig_setmethods__["overlap"] = _csnd.PVSDATEXT_overlap_set
    __swig_getmethods__["overlap"] = _csnd.PVSDATEXT_overlap_get
    if _newclass:overlap = property(_csnd.PVSDATEXT_overlap_get, _csnd.PVSDATEXT_overlap_set)
    __swig_setmethods__["winsize"] = _csnd.PVSDATEXT_winsize_set
    __swig_getmethods__["winsize"] = _csnd.PVSDATEXT_winsize_get
    if _newclass:winsize = property(_csnd.PVSDATEXT_winsize_get, _csnd.PVSDATEXT_winsize_set)
    __swig_setmethods__["wintype"] = _csnd.PVSDATEXT_wintype_set
    __swig_getmethods__["wintype"] = _csnd.PVSDATEXT_wintype_get
    if _newclass:wintype = property(_csnd.PVSDATEXT_wintype_get, _csnd.PVSDATEXT_wintype_set)
    __swig_setmethods__["format"] = _csnd.PVSDATEXT_format_set
    __swig_getmethods__["format"] = _csnd.PVSDATEXT_format_get
    if _newclass:format = property(_csnd.PVSDATEXT_format_get, _csnd.PVSDATEXT_format_set)
    __swig_setmethods__["framecount"] = _csnd.PVSDATEXT_framecount_set
    __swig_getmethods__["framecount"] = _csnd.PVSDATEXT_framecount_get
    if _newclass:framecount = property(_csnd.PVSDATEXT_framecount_get, _csnd.PVSDATEXT_framecount_set)
    __swig_setmethods__["frame"] = _csnd.PVSDATEXT_frame_set
    __swig_getmethods__["frame"] = _csnd.PVSDATEXT_frame_get
    if _newclass:frame = property(_csnd.PVSDATEXT_frame_get, _csnd.PVSDATEXT_frame_set)
    def __init__(self, *args):
        """__init__(self) -> PVSDATEXT"""
        _swig_setattr(self, PVSDATEXT, 'this', _csnd.new_PVSDATEXT(*args))
        _swig_setattr(self, PVSDATEXT, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_PVSDATEXT):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class PVSDATEXTPtr(PVSDATEXT):
    def __init__(self, this):
        _swig_setattr(self, PVSDATEXT, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, PVSDATEXT, 'thisown', 0)
        self.__class__ = PVSDATEXT
_csnd.PVSDATEXT_swigregister(PVSDATEXTPtr)


def csoundInitialize(*args):
    """csoundInitialize(int argc, char argv, int flags) -> int"""
    return _csnd.csoundInitialize(*args)

def csoundCreate(*args):
    """csoundCreate(void hostData) -> CSOUND"""
    return _csnd.csoundCreate(*args)

def csoundPreCompile(*args):
    """csoundPreCompile(CSOUND ??) -> int"""
    return _csnd.csoundPreCompile(*args)

def csoundInitializeCscore(*args):
    """csoundInitializeCscore(CSOUND ??, FILE insco, FILE outsco) -> int"""
    return _csnd.csoundInitializeCscore(*args)

def csoundQueryInterface(*args):
    """csoundQueryInterface(char name, void iface, int version) -> int"""
    return _csnd.csoundQueryInterface(*args)

def csoundDestroy(*args):
    """csoundDestroy(CSOUND ??)"""
    return _csnd.csoundDestroy(*args)

def csoundGetVersion(*args):
    """csoundGetVersion() -> int"""
    return _csnd.csoundGetVersion(*args)

def csoundGetAPIVersion(*args):
    """csoundGetAPIVersion() -> int"""
    return _csnd.csoundGetAPIVersion(*args)

def csoundGetHostData(*args):
    """csoundGetHostData(CSOUND ??) -> void"""
    return _csnd.csoundGetHostData(*args)

def csoundSetHostData(*args):
    """csoundSetHostData(CSOUND ??, void hostData)"""
    return _csnd.csoundSetHostData(*args)

def csoundGetEnv(*args):
    """csoundGetEnv(CSOUND csound, char name) -> char"""
    return _csnd.csoundGetEnv(*args)

def csoundSetGlobalEnv(*args):
    """csoundSetGlobalEnv(char name, char value) -> int"""
    return _csnd.csoundSetGlobalEnv(*args)

def csoundCompile(*args):
    """csoundCompile(CSOUND ??, int argc, char argv) -> int"""
    return _csnd.csoundCompile(*args)

def csoundPerform(*args):
    """csoundPerform(CSOUND ??) -> int"""
    return _csnd.csoundPerform(*args)

def csoundPerformKsmps(*args):
    """csoundPerformKsmps(CSOUND ??) -> int"""
    return _csnd.csoundPerformKsmps(*args)

def csoundPerformKsmpsAbsolute(*args):
    """csoundPerformKsmpsAbsolute(CSOUND ??) -> int"""
    return _csnd.csoundPerformKsmpsAbsolute(*args)

def csoundPerformBuffer(*args):
    """csoundPerformBuffer(CSOUND ??) -> int"""
    return _csnd.csoundPerformBuffer(*args)

def csoundStop(*args):
    """csoundStop(CSOUND ??)"""
    return _csnd.csoundStop(*args)

def csoundCleanup(*args):
    """csoundCleanup(CSOUND ??) -> int"""
    return _csnd.csoundCleanup(*args)

def csoundReset(*args):
    """csoundReset(CSOUND ??)"""
    return _csnd.csoundReset(*args)

def csoundGetSr(*args):
    """csoundGetSr(CSOUND ??) -> float"""
    return _csnd.csoundGetSr(*args)

def csoundGetKr(*args):
    """csoundGetKr(CSOUND ??) -> float"""
    return _csnd.csoundGetKr(*args)

def csoundGetKsmps(*args):
    """csoundGetKsmps(CSOUND ??) -> int"""
    return _csnd.csoundGetKsmps(*args)

def csoundGetNchnls(*args):
    """csoundGetNchnls(CSOUND ??) -> int"""
    return _csnd.csoundGetNchnls(*args)

def csoundGet0dBFS(*args):
    """csoundGet0dBFS(CSOUND ??) -> float"""
    return _csnd.csoundGet0dBFS(*args)

def csoundGetStrVarMaxLen(*args):
    """csoundGetStrVarMaxLen(CSOUND ??) -> int"""
    return _csnd.csoundGetStrVarMaxLen(*args)

def csoundGetSampleFormat(*args):
    """csoundGetSampleFormat(CSOUND ??) -> int"""
    return _csnd.csoundGetSampleFormat(*args)

def csoundGetSampleSize(*args):
    """csoundGetSampleSize(CSOUND ??) -> int"""
    return _csnd.csoundGetSampleSize(*args)

def csoundGetInputBufferSize(*args):
    """csoundGetInputBufferSize(CSOUND ??) -> long"""
    return _csnd.csoundGetInputBufferSize(*args)

def csoundGetOutputBufferSize(*args):
    """csoundGetOutputBufferSize(CSOUND ??) -> long"""
    return _csnd.csoundGetOutputBufferSize(*args)

def csoundGetInputBuffer(*args):
    """csoundGetInputBuffer(CSOUND ??) -> float"""
    return _csnd.csoundGetInputBuffer(*args)

def csoundGetOutputBuffer(*args):
    """csoundGetOutputBuffer(CSOUND ??) -> float"""
    return _csnd.csoundGetOutputBuffer(*args)

def csoundGetSpin(*args):
    """csoundGetSpin(CSOUND ??) -> float"""
    return _csnd.csoundGetSpin(*args)

def csoundGetSpout(*args):
    """csoundGetSpout(CSOUND ??) -> float"""
    return _csnd.csoundGetSpout(*args)

def csoundGetOutputFileName(*args):
    """csoundGetOutputFileName(CSOUND ??) -> char"""
    return _csnd.csoundGetOutputFileName(*args)

def csoundSetHostImplementedAudioIO(*args):
    """csoundSetHostImplementedAudioIO(CSOUND ??, int state, int bufSize)"""
    return _csnd.csoundSetHostImplementedAudioIO(*args)

def csoundGetScoreTime(*args):
    """csoundGetScoreTime(CSOUND ??) -> double"""
    return _csnd.csoundGetScoreTime(*args)

def csoundIsScorePending(*args):
    """csoundIsScorePending(CSOUND ??) -> int"""
    return _csnd.csoundIsScorePending(*args)

def csoundSetScorePending(*args):
    """csoundSetScorePending(CSOUND ??, int pending)"""
    return _csnd.csoundSetScorePending(*args)

def csoundGetScoreOffsetSeconds(*args):
    """csoundGetScoreOffsetSeconds(CSOUND ??) -> float"""
    return _csnd.csoundGetScoreOffsetSeconds(*args)

def csoundSetScoreOffsetSeconds(*args):
    """csoundSetScoreOffsetSeconds(CSOUND ??, float time)"""
    return _csnd.csoundSetScoreOffsetSeconds(*args)

def csoundRewindScore(*args):
    """csoundRewindScore(CSOUND ??)"""
    return _csnd.csoundRewindScore(*args)

def csoundScoreSort(*args):
    """csoundScoreSort(CSOUND ??, FILE inFile, FILE outFile) -> int"""
    return _csnd.csoundScoreSort(*args)

def csoundScoreExtract(*args):
    """csoundScoreExtract(CSOUND ??, FILE inFile, FILE outFile, FILE extractFile) -> int"""
    return _csnd.csoundScoreExtract(*args)

def csoundMessage(*args):
    """csoundMessage(CSOUND ??, char format, v(...) ??)"""
    return _csnd.csoundMessage(*args)

def csoundMessageS(*args):
    """csoundMessageS(CSOUND ??, int attr, char format, v(...) ??)"""
    return _csnd.csoundMessageS(*args)

def csoundGetMessageLevel(*args):
    """csoundGetMessageLevel(CSOUND ??) -> int"""
    return _csnd.csoundGetMessageLevel(*args)

def csoundSetMessageLevel(*args):
    """csoundSetMessageLevel(CSOUND ??, int messageLevel)"""
    return _csnd.csoundSetMessageLevel(*args)

def csoundInputMessage(*args):
    """csoundInputMessage(CSOUND ??, char message)"""
    return _csnd.csoundInputMessage(*args)

def csoundKeyPress(*args):
    """csoundKeyPress(CSOUND ??, char c)"""
    return _csnd.csoundKeyPress(*args)

def csoundScoreEvent(*args):
    """csoundScoreEvent(CSOUND ??, char type, float pFields, long numFields) -> int"""
    return _csnd.csoundScoreEvent(*args)

def csoundNewOpcodeList(*args):
    """csoundNewOpcodeList(CSOUND ??, opcodeListEntry opcodelist) -> int"""
    return _csnd.csoundNewOpcodeList(*args)

def csoundDisposeOpcodeList(*args):
    """csoundDisposeOpcodeList(CSOUND ??, opcodeListEntry opcodelist)"""
    return _csnd.csoundDisposeOpcodeList(*args)

def csoundAppendOpcode(*args):
    """
    csoundAppendOpcode(CSOUND ??, char opname, int dsblksiz, int thread, char outypes, 
        char intypes, int iopadr, int kopadr, 
        int aopadr) -> int
    """
    return _csnd.csoundAppendOpcode(*args)

def csoundOpenLibrary(*args):
    """csoundOpenLibrary(void library, char libraryPath) -> int"""
    return _csnd.csoundOpenLibrary(*args)

def csoundCloseLibrary(*args):
    """csoundCloseLibrary(void library) -> int"""
    return _csnd.csoundCloseLibrary(*args)

def csoundGetLibrarySymbol(*args):
    """csoundGetLibrarySymbol(void library, char symbolName) -> void"""
    return _csnd.csoundGetLibrarySymbol(*args)

def csoundGetDebug(*args):
    """csoundGetDebug(CSOUND ??) -> int"""
    return _csnd.csoundGetDebug(*args)

def csoundSetDebug(*args):
    """csoundSetDebug(CSOUND ??, int debug)"""
    return _csnd.csoundSetDebug(*args)

def csoundTableLength(*args):
    """csoundTableLength(CSOUND ??, int table) -> int"""
    return _csnd.csoundTableLength(*args)

def csoundTableGet(*args):
    """csoundTableGet(CSOUND ??, int table, int index) -> float"""
    return _csnd.csoundTableGet(*args)

def csoundTableSet(*args):
    """csoundTableSet(CSOUND ??, int table, int index, float value)"""
    return _csnd.csoundTableSet(*args)

def csoundGetTable(*args):
    """csoundGetTable(CSOUND ??, float tablePtr, int tableNum) -> int"""
    return _csnd.csoundGetTable(*args)

def csoundCreateThread(*args):
    """csoundCreateThread(uintptr_t threadRoutine, void userdata) -> void"""
    return _csnd.csoundCreateThread(*args)

def csoundGetCurrentThreadId(*args):
    """csoundGetCurrentThreadId() -> void"""
    return _csnd.csoundGetCurrentThreadId(*args)

def csoundJoinThread(*args):
    """csoundJoinThread(void thread) -> uintptr_t"""
    return _csnd.csoundJoinThread(*args)

def csoundRunCommand(*args):
    """csoundRunCommand(char argv, int noWait) -> long"""
    return _csnd.csoundRunCommand(*args)

def csoundCreateThreadLock(*args):
    """csoundCreateThreadLock() -> void"""
    return _csnd.csoundCreateThreadLock(*args)

def csoundWaitThreadLock(*args):
    """csoundWaitThreadLock(void lock, size_t milliseconds) -> int"""
    return _csnd.csoundWaitThreadLock(*args)

def csoundWaitThreadLockNoTimeout(*args):
    """csoundWaitThreadLockNoTimeout(void lock)"""
    return _csnd.csoundWaitThreadLockNoTimeout(*args)

def csoundNotifyThreadLock(*args):
    """csoundNotifyThreadLock(void lock)"""
    return _csnd.csoundNotifyThreadLock(*args)

def csoundDestroyThreadLock(*args):
    """csoundDestroyThreadLock(void lock)"""
    return _csnd.csoundDestroyThreadLock(*args)

def csoundCreateMutex(*args):
    """csoundCreateMutex(int isRecursive) -> void"""
    return _csnd.csoundCreateMutex(*args)

def csoundLockMutex(*args):
    """csoundLockMutex(void mutex_)"""
    return _csnd.csoundLockMutex(*args)

def csoundLockMutexNoWait(*args):
    """csoundLockMutexNoWait(void mutex_) -> int"""
    return _csnd.csoundLockMutexNoWait(*args)

def csoundUnlockMutex(*args):
    """csoundUnlockMutex(void mutex_)"""
    return _csnd.csoundUnlockMutex(*args)

def csoundDestroyMutex(*args):
    """csoundDestroyMutex(void mutex_)"""
    return _csnd.csoundDestroyMutex(*args)

def csoundSleep(*args):
    """csoundSleep(size_t milliseconds)"""
    return _csnd.csoundSleep(*args)

def csoundInitTimerStruct(*args):
    """csoundInitTimerStruct( ??)"""
    return _csnd.csoundInitTimerStruct(*args)

def csoundGetRealTime(*args):
    """csoundGetRealTime( ??) -> double"""
    return _csnd.csoundGetRealTime(*args)

def csoundGetCPUTime(*args):
    """csoundGetCPUTime( ??) -> double"""
    return _csnd.csoundGetCPUTime(*args)

def csoundGetRandomSeedFromTime(*args):
    """csoundGetRandomSeedFromTime() -> uint32_t"""
    return _csnd.csoundGetRandomSeedFromTime(*args)

def csoundSetLanguage(*args):
    """csoundSetLanguage(cslanguage_t lang_code)"""
    return _csnd.csoundSetLanguage(*args)

def csoundLocalizeString(*args):
    """csoundLocalizeString(char s) -> char"""
    return _csnd.csoundLocalizeString(*args)

def csoundCreateGlobalVariable(*args):
    """csoundCreateGlobalVariable(CSOUND ??, char name, size_t nbytes) -> int"""
    return _csnd.csoundCreateGlobalVariable(*args)

def csoundQueryGlobalVariable(*args):
    """csoundQueryGlobalVariable(CSOUND ??, char name) -> void"""
    return _csnd.csoundQueryGlobalVariable(*args)

def csoundQueryGlobalVariableNoCheck(*args):
    """csoundQueryGlobalVariableNoCheck(CSOUND ??, char name) -> void"""
    return _csnd.csoundQueryGlobalVariableNoCheck(*args)

def csoundDestroyGlobalVariable(*args):
    """csoundDestroyGlobalVariable(CSOUND ??, char name) -> int"""
    return _csnd.csoundDestroyGlobalVariable(*args)

def csoundGetSizeOfMYFLT(*args):
    """csoundGetSizeOfMYFLT() -> int"""
    return _csnd.csoundGetSizeOfMYFLT(*args)

def csoundGetRtRecordUserData(*args):
    """csoundGetRtRecordUserData(CSOUND ??) -> void"""
    return _csnd.csoundGetRtRecordUserData(*args)

def csoundGetRtPlayUserData(*args):
    """csoundGetRtPlayUserData(CSOUND ??) -> void"""
    return _csnd.csoundGetRtPlayUserData(*args)

def csoundRunUtility(*args):
    """csoundRunUtility(CSOUND ??, char name, int argc, char argv) -> int"""
    return _csnd.csoundRunUtility(*args)

def csoundListUtilities(*args):
    """csoundListUtilities(CSOUND ??) -> char"""
    return _csnd.csoundListUtilities(*args)

def csoundDeleteUtilityList(*args):
    """csoundDeleteUtilityList(CSOUND ??, char lst)"""
    return _csnd.csoundDeleteUtilityList(*args)

def csoundGetUtilityDescription(*args):
    """csoundGetUtilityDescription(CSOUND ??, char utilName) -> char"""
    return _csnd.csoundGetUtilityDescription(*args)

def csoundGetChannelPtr(*args):
    """csoundGetChannelPtr(CSOUND ??, float p, char name, int type) -> int"""
    return _csnd.csoundGetChannelPtr(*args)

def csoundListChannels(*args):
    """csoundListChannels(CSOUND ??,  lst) -> int"""
    return _csnd.csoundListChannels(*args)

def csoundDeleteChannelList(*args):
    """csoundDeleteChannelList(CSOUND ??,  lst)"""
    return _csnd.csoundDeleteChannelList(*args)

def csoundSetControlChannelParams(*args):
    """
    csoundSetControlChannelParams(CSOUND ??, char name, int type, float dflt, float min, 
        float max) -> int
    """
    return _csnd.csoundSetControlChannelParams(*args)

def csoundGetControlChannelParams(*args):
    """csoundGetControlChannelParams(CSOUND ??, char name, float dflt, float min, float max) -> int"""
    return _csnd.csoundGetControlChannelParams(*args)

def csoundSetChannelIOCallback(*args):
    """csoundSetChannelIOCallback(CSOUND ??, CsoundChannelIOCallback_t func)"""
    return _csnd.csoundSetChannelIOCallback(*args)

def csoundRand31(*args):
    """csoundRand31(int seedVal) -> int"""
    return _csnd.csoundRand31(*args)

def csoundSeedRandMT(*args):
    """csoundSeedRandMT( p, uint32_t initKey, uint32_t keyLength)"""
    return _csnd.csoundSeedRandMT(*args)

def csoundRandMT(*args):
    """csoundRandMT( p) -> uint32_t"""
    return _csnd.csoundRandMT(*args)

def csoundChanIKSet(*args):
    """csoundChanIKSet(CSOUND ??, float value, int n) -> int"""
    return _csnd.csoundChanIKSet(*args)

def csoundChanOKGet(*args):
    """csoundChanOKGet(CSOUND ??, float value, int n) -> int"""
    return _csnd.csoundChanOKGet(*args)

def csoundChanIASet(*args):
    """csoundChanIASet(CSOUND ??, float value, int n) -> int"""
    return _csnd.csoundChanIASet(*args)

def csoundChanOAGet(*args):
    """csoundChanOAGet(CSOUND ??, float value, int n) -> int"""
    return _csnd.csoundChanOAGet(*args)

def csoundPvsinSet(*args):
    """csoundPvsinSet(CSOUND ??,  fin, int n) -> int"""
    return _csnd.csoundPvsinSet(*args)

def csoundPvsoutGet(*args):
    """csoundPvsoutGet(CSOUND csound,  fout, int n) -> int"""
    return _csnd.csoundPvsoutGet(*args)

def csoundSetCallback(*args):
    """csoundSetCallback(CSOUND ??, int func, void userData, unsigned int typeMask) -> int"""
    return _csnd.csoundSetCallback(*args)

def csoundRemoveCallback(*args):
    """csoundRemoveCallback(CSOUND ??, int func)"""
    return _csnd.csoundRemoveCallback(*args)
class csCfgVariableHead_t(_object):
    """Proxy of C++ csCfgVariableHead_t class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, csCfgVariableHead_t, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, csCfgVariableHead_t, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ csCfgVariableHead_t instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["nxt"] = _csnd.csCfgVariableHead_t_nxt_set
    __swig_getmethods__["nxt"] = _csnd.csCfgVariableHead_t_nxt_get
    if _newclass:nxt = property(_csnd.csCfgVariableHead_t_nxt_get, _csnd.csCfgVariableHead_t_nxt_set)
    __swig_setmethods__["name"] = _csnd.csCfgVariableHead_t_name_set
    __swig_getmethods__["name"] = _csnd.csCfgVariableHead_t_name_get
    if _newclass:name = property(_csnd.csCfgVariableHead_t_name_get, _csnd.csCfgVariableHead_t_name_set)
    __swig_setmethods__["p"] = _csnd.csCfgVariableHead_t_p_set
    __swig_getmethods__["p"] = _csnd.csCfgVariableHead_t_p_get
    if _newclass:p = property(_csnd.csCfgVariableHead_t_p_get, _csnd.csCfgVariableHead_t_p_set)
    __swig_setmethods__["type"] = _csnd.csCfgVariableHead_t_type_set
    __swig_getmethods__["type"] = _csnd.csCfgVariableHead_t_type_get
    if _newclass:type = property(_csnd.csCfgVariableHead_t_type_get, _csnd.csCfgVariableHead_t_type_set)
    __swig_setmethods__["flags"] = _csnd.csCfgVariableHead_t_flags_set
    __swig_getmethods__["flags"] = _csnd.csCfgVariableHead_t_flags_get
    if _newclass:flags = property(_csnd.csCfgVariableHead_t_flags_get, _csnd.csCfgVariableHead_t_flags_set)
    __swig_setmethods__["shortDesc"] = _csnd.csCfgVariableHead_t_shortDesc_set
    __swig_getmethods__["shortDesc"] = _csnd.csCfgVariableHead_t_shortDesc_get
    if _newclass:shortDesc = property(_csnd.csCfgVariableHead_t_shortDesc_get, _csnd.csCfgVariableHead_t_shortDesc_set)
    __swig_setmethods__["longDesc"] = _csnd.csCfgVariableHead_t_longDesc_set
    __swig_getmethods__["longDesc"] = _csnd.csCfgVariableHead_t_longDesc_get
    if _newclass:longDesc = property(_csnd.csCfgVariableHead_t_longDesc_get, _csnd.csCfgVariableHead_t_longDesc_set)
    def __init__(self, *args):
        """__init__(self) -> csCfgVariableHead_t"""
        _swig_setattr(self, csCfgVariableHead_t, 'this', _csnd.new_csCfgVariableHead_t(*args))
        _swig_setattr(self, csCfgVariableHead_t, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_csCfgVariableHead_t):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class csCfgVariableHead_tPtr(csCfgVariableHead_t):
    def __init__(self, this):
        _swig_setattr(self, csCfgVariableHead_t, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, csCfgVariableHead_t, 'thisown', 0)
        self.__class__ = csCfgVariableHead_t
_csnd.csCfgVariableHead_t_swigregister(csCfgVariableHead_tPtr)

class csCfgVariableInt_t(_object):
    """Proxy of C++ csCfgVariableInt_t class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, csCfgVariableInt_t, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, csCfgVariableInt_t, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ csCfgVariableInt_t instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["nxt"] = _csnd.csCfgVariableInt_t_nxt_set
    __swig_getmethods__["nxt"] = _csnd.csCfgVariableInt_t_nxt_get
    if _newclass:nxt = property(_csnd.csCfgVariableInt_t_nxt_get, _csnd.csCfgVariableInt_t_nxt_set)
    __swig_setmethods__["name"] = _csnd.csCfgVariableInt_t_name_set
    __swig_getmethods__["name"] = _csnd.csCfgVariableInt_t_name_get
    if _newclass:name = property(_csnd.csCfgVariableInt_t_name_get, _csnd.csCfgVariableInt_t_name_set)
    __swig_setmethods__["p"] = _csnd.csCfgVariableInt_t_p_set
    __swig_getmethods__["p"] = _csnd.csCfgVariableInt_t_p_get
    if _newclass:p = property(_csnd.csCfgVariableInt_t_p_get, _csnd.csCfgVariableInt_t_p_set)
    __swig_setmethods__["type"] = _csnd.csCfgVariableInt_t_type_set
    __swig_getmethods__["type"] = _csnd.csCfgVariableInt_t_type_get
    if _newclass:type = property(_csnd.csCfgVariableInt_t_type_get, _csnd.csCfgVariableInt_t_type_set)
    __swig_setmethods__["flags"] = _csnd.csCfgVariableInt_t_flags_set
    __swig_getmethods__["flags"] = _csnd.csCfgVariableInt_t_flags_get
    if _newclass:flags = property(_csnd.csCfgVariableInt_t_flags_get, _csnd.csCfgVariableInt_t_flags_set)
    __swig_setmethods__["shortDesc"] = _csnd.csCfgVariableInt_t_shortDesc_set
    __swig_getmethods__["shortDesc"] = _csnd.csCfgVariableInt_t_shortDesc_get
    if _newclass:shortDesc = property(_csnd.csCfgVariableInt_t_shortDesc_get, _csnd.csCfgVariableInt_t_shortDesc_set)
    __swig_setmethods__["longDesc"] = _csnd.csCfgVariableInt_t_longDesc_set
    __swig_getmethods__["longDesc"] = _csnd.csCfgVariableInt_t_longDesc_get
    if _newclass:longDesc = property(_csnd.csCfgVariableInt_t_longDesc_get, _csnd.csCfgVariableInt_t_longDesc_set)
    __swig_setmethods__["min"] = _csnd.csCfgVariableInt_t_min_set
    __swig_getmethods__["min"] = _csnd.csCfgVariableInt_t_min_get
    if _newclass:min = property(_csnd.csCfgVariableInt_t_min_get, _csnd.csCfgVariableInt_t_min_set)
    __swig_setmethods__["max"] = _csnd.csCfgVariableInt_t_max_set
    __swig_getmethods__["max"] = _csnd.csCfgVariableInt_t_max_get
    if _newclass:max = property(_csnd.csCfgVariableInt_t_max_get, _csnd.csCfgVariableInt_t_max_set)
    def __init__(self, *args):
        """__init__(self) -> csCfgVariableInt_t"""
        _swig_setattr(self, csCfgVariableInt_t, 'this', _csnd.new_csCfgVariableInt_t(*args))
        _swig_setattr(self, csCfgVariableInt_t, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_csCfgVariableInt_t):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class csCfgVariableInt_tPtr(csCfgVariableInt_t):
    def __init__(self, this):
        _swig_setattr(self, csCfgVariableInt_t, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, csCfgVariableInt_t, 'thisown', 0)
        self.__class__ = csCfgVariableInt_t
_csnd.csCfgVariableInt_t_swigregister(csCfgVariableInt_tPtr)

class csCfgVariableBoolean_t(_object):
    """Proxy of C++ csCfgVariableBoolean_t class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, csCfgVariableBoolean_t, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, csCfgVariableBoolean_t, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ csCfgVariableBoolean_t instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["nxt"] = _csnd.csCfgVariableBoolean_t_nxt_set
    __swig_getmethods__["nxt"] = _csnd.csCfgVariableBoolean_t_nxt_get
    if _newclass:nxt = property(_csnd.csCfgVariableBoolean_t_nxt_get, _csnd.csCfgVariableBoolean_t_nxt_set)
    __swig_setmethods__["name"] = _csnd.csCfgVariableBoolean_t_name_set
    __swig_getmethods__["name"] = _csnd.csCfgVariableBoolean_t_name_get
    if _newclass:name = property(_csnd.csCfgVariableBoolean_t_name_get, _csnd.csCfgVariableBoolean_t_name_set)
    __swig_setmethods__["p"] = _csnd.csCfgVariableBoolean_t_p_set
    __swig_getmethods__["p"] = _csnd.csCfgVariableBoolean_t_p_get
    if _newclass:p = property(_csnd.csCfgVariableBoolean_t_p_get, _csnd.csCfgVariableBoolean_t_p_set)
    __swig_setmethods__["type"] = _csnd.csCfgVariableBoolean_t_type_set
    __swig_getmethods__["type"] = _csnd.csCfgVariableBoolean_t_type_get
    if _newclass:type = property(_csnd.csCfgVariableBoolean_t_type_get, _csnd.csCfgVariableBoolean_t_type_set)
    __swig_setmethods__["flags"] = _csnd.csCfgVariableBoolean_t_flags_set
    __swig_getmethods__["flags"] = _csnd.csCfgVariableBoolean_t_flags_get
    if _newclass:flags = property(_csnd.csCfgVariableBoolean_t_flags_get, _csnd.csCfgVariableBoolean_t_flags_set)
    __swig_setmethods__["shortDesc"] = _csnd.csCfgVariableBoolean_t_shortDesc_set
    __swig_getmethods__["shortDesc"] = _csnd.csCfgVariableBoolean_t_shortDesc_get
    if _newclass:shortDesc = property(_csnd.csCfgVariableBoolean_t_shortDesc_get, _csnd.csCfgVariableBoolean_t_shortDesc_set)
    __swig_setmethods__["longDesc"] = _csnd.csCfgVariableBoolean_t_longDesc_set
    __swig_getmethods__["longDesc"] = _csnd.csCfgVariableBoolean_t_longDesc_get
    if _newclass:longDesc = property(_csnd.csCfgVariableBoolean_t_longDesc_get, _csnd.csCfgVariableBoolean_t_longDesc_set)
    def __init__(self, *args):
        """__init__(self) -> csCfgVariableBoolean_t"""
        _swig_setattr(self, csCfgVariableBoolean_t, 'this', _csnd.new_csCfgVariableBoolean_t(*args))
        _swig_setattr(self, csCfgVariableBoolean_t, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_csCfgVariableBoolean_t):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class csCfgVariableBoolean_tPtr(csCfgVariableBoolean_t):
    def __init__(self, this):
        _swig_setattr(self, csCfgVariableBoolean_t, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, csCfgVariableBoolean_t, 'thisown', 0)
        self.__class__ = csCfgVariableBoolean_t
_csnd.csCfgVariableBoolean_t_swigregister(csCfgVariableBoolean_tPtr)

class csCfgVariableFloat_t(_object):
    """Proxy of C++ csCfgVariableFloat_t class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, csCfgVariableFloat_t, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, csCfgVariableFloat_t, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ csCfgVariableFloat_t instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["nxt"] = _csnd.csCfgVariableFloat_t_nxt_set
    __swig_getmethods__["nxt"] = _csnd.csCfgVariableFloat_t_nxt_get
    if _newclass:nxt = property(_csnd.csCfgVariableFloat_t_nxt_get, _csnd.csCfgVariableFloat_t_nxt_set)
    __swig_setmethods__["name"] = _csnd.csCfgVariableFloat_t_name_set
    __swig_getmethods__["name"] = _csnd.csCfgVariableFloat_t_name_get
    if _newclass:name = property(_csnd.csCfgVariableFloat_t_name_get, _csnd.csCfgVariableFloat_t_name_set)
    __swig_setmethods__["p"] = _csnd.csCfgVariableFloat_t_p_set
    __swig_getmethods__["p"] = _csnd.csCfgVariableFloat_t_p_get
    if _newclass:p = property(_csnd.csCfgVariableFloat_t_p_get, _csnd.csCfgVariableFloat_t_p_set)
    __swig_setmethods__["type"] = _csnd.csCfgVariableFloat_t_type_set
    __swig_getmethods__["type"] = _csnd.csCfgVariableFloat_t_type_get
    if _newclass:type = property(_csnd.csCfgVariableFloat_t_type_get, _csnd.csCfgVariableFloat_t_type_set)
    __swig_setmethods__["flags"] = _csnd.csCfgVariableFloat_t_flags_set
    __swig_getmethods__["flags"] = _csnd.csCfgVariableFloat_t_flags_get
    if _newclass:flags = property(_csnd.csCfgVariableFloat_t_flags_get, _csnd.csCfgVariableFloat_t_flags_set)
    __swig_setmethods__["shortDesc"] = _csnd.csCfgVariableFloat_t_shortDesc_set
    __swig_getmethods__["shortDesc"] = _csnd.csCfgVariableFloat_t_shortDesc_get
    if _newclass:shortDesc = property(_csnd.csCfgVariableFloat_t_shortDesc_get, _csnd.csCfgVariableFloat_t_shortDesc_set)
    __swig_setmethods__["longDesc"] = _csnd.csCfgVariableFloat_t_longDesc_set
    __swig_getmethods__["longDesc"] = _csnd.csCfgVariableFloat_t_longDesc_get
    if _newclass:longDesc = property(_csnd.csCfgVariableFloat_t_longDesc_get, _csnd.csCfgVariableFloat_t_longDesc_set)
    __swig_setmethods__["min"] = _csnd.csCfgVariableFloat_t_min_set
    __swig_getmethods__["min"] = _csnd.csCfgVariableFloat_t_min_get
    if _newclass:min = property(_csnd.csCfgVariableFloat_t_min_get, _csnd.csCfgVariableFloat_t_min_set)
    __swig_setmethods__["max"] = _csnd.csCfgVariableFloat_t_max_set
    __swig_getmethods__["max"] = _csnd.csCfgVariableFloat_t_max_get
    if _newclass:max = property(_csnd.csCfgVariableFloat_t_max_get, _csnd.csCfgVariableFloat_t_max_set)
    def __init__(self, *args):
        """__init__(self) -> csCfgVariableFloat_t"""
        _swig_setattr(self, csCfgVariableFloat_t, 'this', _csnd.new_csCfgVariableFloat_t(*args))
        _swig_setattr(self, csCfgVariableFloat_t, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_csCfgVariableFloat_t):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class csCfgVariableFloat_tPtr(csCfgVariableFloat_t):
    def __init__(self, this):
        _swig_setattr(self, csCfgVariableFloat_t, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, csCfgVariableFloat_t, 'thisown', 0)
        self.__class__ = csCfgVariableFloat_t
_csnd.csCfgVariableFloat_t_swigregister(csCfgVariableFloat_tPtr)

class csCfgVariableDouble_t(_object):
    """Proxy of C++ csCfgVariableDouble_t class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, csCfgVariableDouble_t, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, csCfgVariableDouble_t, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ csCfgVariableDouble_t instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["nxt"] = _csnd.csCfgVariableDouble_t_nxt_set
    __swig_getmethods__["nxt"] = _csnd.csCfgVariableDouble_t_nxt_get
    if _newclass:nxt = property(_csnd.csCfgVariableDouble_t_nxt_get, _csnd.csCfgVariableDouble_t_nxt_set)
    __swig_setmethods__["name"] = _csnd.csCfgVariableDouble_t_name_set
    __swig_getmethods__["name"] = _csnd.csCfgVariableDouble_t_name_get
    if _newclass:name = property(_csnd.csCfgVariableDouble_t_name_get, _csnd.csCfgVariableDouble_t_name_set)
    __swig_setmethods__["p"] = _csnd.csCfgVariableDouble_t_p_set
    __swig_getmethods__["p"] = _csnd.csCfgVariableDouble_t_p_get
    if _newclass:p = property(_csnd.csCfgVariableDouble_t_p_get, _csnd.csCfgVariableDouble_t_p_set)
    __swig_setmethods__["type"] = _csnd.csCfgVariableDouble_t_type_set
    __swig_getmethods__["type"] = _csnd.csCfgVariableDouble_t_type_get
    if _newclass:type = property(_csnd.csCfgVariableDouble_t_type_get, _csnd.csCfgVariableDouble_t_type_set)
    __swig_setmethods__["flags"] = _csnd.csCfgVariableDouble_t_flags_set
    __swig_getmethods__["flags"] = _csnd.csCfgVariableDouble_t_flags_get
    if _newclass:flags = property(_csnd.csCfgVariableDouble_t_flags_get, _csnd.csCfgVariableDouble_t_flags_set)
    __swig_setmethods__["shortDesc"] = _csnd.csCfgVariableDouble_t_shortDesc_set
    __swig_getmethods__["shortDesc"] = _csnd.csCfgVariableDouble_t_shortDesc_get
    if _newclass:shortDesc = property(_csnd.csCfgVariableDouble_t_shortDesc_get, _csnd.csCfgVariableDouble_t_shortDesc_set)
    __swig_setmethods__["longDesc"] = _csnd.csCfgVariableDouble_t_longDesc_set
    __swig_getmethods__["longDesc"] = _csnd.csCfgVariableDouble_t_longDesc_get
    if _newclass:longDesc = property(_csnd.csCfgVariableDouble_t_longDesc_get, _csnd.csCfgVariableDouble_t_longDesc_set)
    __swig_setmethods__["min"] = _csnd.csCfgVariableDouble_t_min_set
    __swig_getmethods__["min"] = _csnd.csCfgVariableDouble_t_min_get
    if _newclass:min = property(_csnd.csCfgVariableDouble_t_min_get, _csnd.csCfgVariableDouble_t_min_set)
    __swig_setmethods__["max"] = _csnd.csCfgVariableDouble_t_max_set
    __swig_getmethods__["max"] = _csnd.csCfgVariableDouble_t_max_get
    if _newclass:max = property(_csnd.csCfgVariableDouble_t_max_get, _csnd.csCfgVariableDouble_t_max_set)
    def __init__(self, *args):
        """__init__(self) -> csCfgVariableDouble_t"""
        _swig_setattr(self, csCfgVariableDouble_t, 'this', _csnd.new_csCfgVariableDouble_t(*args))
        _swig_setattr(self, csCfgVariableDouble_t, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_csCfgVariableDouble_t):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class csCfgVariableDouble_tPtr(csCfgVariableDouble_t):
    def __init__(self, this):
        _swig_setattr(self, csCfgVariableDouble_t, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, csCfgVariableDouble_t, 'thisown', 0)
        self.__class__ = csCfgVariableDouble_t
_csnd.csCfgVariableDouble_t_swigregister(csCfgVariableDouble_tPtr)

class csCfgVariableMYFLT_t(_object):
    """Proxy of C++ csCfgVariableMYFLT_t class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, csCfgVariableMYFLT_t, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, csCfgVariableMYFLT_t, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ csCfgVariableMYFLT_t instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["nxt"] = _csnd.csCfgVariableMYFLT_t_nxt_set
    __swig_getmethods__["nxt"] = _csnd.csCfgVariableMYFLT_t_nxt_get
    if _newclass:nxt = property(_csnd.csCfgVariableMYFLT_t_nxt_get, _csnd.csCfgVariableMYFLT_t_nxt_set)
    __swig_setmethods__["name"] = _csnd.csCfgVariableMYFLT_t_name_set
    __swig_getmethods__["name"] = _csnd.csCfgVariableMYFLT_t_name_get
    if _newclass:name = property(_csnd.csCfgVariableMYFLT_t_name_get, _csnd.csCfgVariableMYFLT_t_name_set)
    __swig_setmethods__["p"] = _csnd.csCfgVariableMYFLT_t_p_set
    __swig_getmethods__["p"] = _csnd.csCfgVariableMYFLT_t_p_get
    if _newclass:p = property(_csnd.csCfgVariableMYFLT_t_p_get, _csnd.csCfgVariableMYFLT_t_p_set)
    __swig_setmethods__["type"] = _csnd.csCfgVariableMYFLT_t_type_set
    __swig_getmethods__["type"] = _csnd.csCfgVariableMYFLT_t_type_get
    if _newclass:type = property(_csnd.csCfgVariableMYFLT_t_type_get, _csnd.csCfgVariableMYFLT_t_type_set)
    __swig_setmethods__["flags"] = _csnd.csCfgVariableMYFLT_t_flags_set
    __swig_getmethods__["flags"] = _csnd.csCfgVariableMYFLT_t_flags_get
    if _newclass:flags = property(_csnd.csCfgVariableMYFLT_t_flags_get, _csnd.csCfgVariableMYFLT_t_flags_set)
    __swig_setmethods__["shortDesc"] = _csnd.csCfgVariableMYFLT_t_shortDesc_set
    __swig_getmethods__["shortDesc"] = _csnd.csCfgVariableMYFLT_t_shortDesc_get
    if _newclass:shortDesc = property(_csnd.csCfgVariableMYFLT_t_shortDesc_get, _csnd.csCfgVariableMYFLT_t_shortDesc_set)
    __swig_setmethods__["longDesc"] = _csnd.csCfgVariableMYFLT_t_longDesc_set
    __swig_getmethods__["longDesc"] = _csnd.csCfgVariableMYFLT_t_longDesc_get
    if _newclass:longDesc = property(_csnd.csCfgVariableMYFLT_t_longDesc_get, _csnd.csCfgVariableMYFLT_t_longDesc_set)
    __swig_setmethods__["min"] = _csnd.csCfgVariableMYFLT_t_min_set
    __swig_getmethods__["min"] = _csnd.csCfgVariableMYFLT_t_min_get
    if _newclass:min = property(_csnd.csCfgVariableMYFLT_t_min_get, _csnd.csCfgVariableMYFLT_t_min_set)
    __swig_setmethods__["max"] = _csnd.csCfgVariableMYFLT_t_max_set
    __swig_getmethods__["max"] = _csnd.csCfgVariableMYFLT_t_max_get
    if _newclass:max = property(_csnd.csCfgVariableMYFLT_t_max_get, _csnd.csCfgVariableMYFLT_t_max_set)
    def __init__(self, *args):
        """__init__(self) -> csCfgVariableMYFLT_t"""
        _swig_setattr(self, csCfgVariableMYFLT_t, 'this', _csnd.new_csCfgVariableMYFLT_t(*args))
        _swig_setattr(self, csCfgVariableMYFLT_t, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_csCfgVariableMYFLT_t):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class csCfgVariableMYFLT_tPtr(csCfgVariableMYFLT_t):
    def __init__(self, this):
        _swig_setattr(self, csCfgVariableMYFLT_t, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, csCfgVariableMYFLT_t, 'thisown', 0)
        self.__class__ = csCfgVariableMYFLT_t
_csnd.csCfgVariableMYFLT_t_swigregister(csCfgVariableMYFLT_tPtr)

class csCfgVariableString_t(_object):
    """Proxy of C++ csCfgVariableString_t class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, csCfgVariableString_t, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, csCfgVariableString_t, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ csCfgVariableString_t instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["nxt"] = _csnd.csCfgVariableString_t_nxt_set
    __swig_getmethods__["nxt"] = _csnd.csCfgVariableString_t_nxt_get
    if _newclass:nxt = property(_csnd.csCfgVariableString_t_nxt_get, _csnd.csCfgVariableString_t_nxt_set)
    __swig_setmethods__["name"] = _csnd.csCfgVariableString_t_name_set
    __swig_getmethods__["name"] = _csnd.csCfgVariableString_t_name_get
    if _newclass:name = property(_csnd.csCfgVariableString_t_name_get, _csnd.csCfgVariableString_t_name_set)
    __swig_setmethods__["p"] = _csnd.csCfgVariableString_t_p_set
    __swig_getmethods__["p"] = _csnd.csCfgVariableString_t_p_get
    if _newclass:p = property(_csnd.csCfgVariableString_t_p_get, _csnd.csCfgVariableString_t_p_set)
    __swig_setmethods__["type"] = _csnd.csCfgVariableString_t_type_set
    __swig_getmethods__["type"] = _csnd.csCfgVariableString_t_type_get
    if _newclass:type = property(_csnd.csCfgVariableString_t_type_get, _csnd.csCfgVariableString_t_type_set)
    __swig_setmethods__["flags"] = _csnd.csCfgVariableString_t_flags_set
    __swig_getmethods__["flags"] = _csnd.csCfgVariableString_t_flags_get
    if _newclass:flags = property(_csnd.csCfgVariableString_t_flags_get, _csnd.csCfgVariableString_t_flags_set)
    __swig_setmethods__["shortDesc"] = _csnd.csCfgVariableString_t_shortDesc_set
    __swig_getmethods__["shortDesc"] = _csnd.csCfgVariableString_t_shortDesc_get
    if _newclass:shortDesc = property(_csnd.csCfgVariableString_t_shortDesc_get, _csnd.csCfgVariableString_t_shortDesc_set)
    __swig_setmethods__["longDesc"] = _csnd.csCfgVariableString_t_longDesc_set
    __swig_getmethods__["longDesc"] = _csnd.csCfgVariableString_t_longDesc_get
    if _newclass:longDesc = property(_csnd.csCfgVariableString_t_longDesc_get, _csnd.csCfgVariableString_t_longDesc_set)
    __swig_setmethods__["maxlen"] = _csnd.csCfgVariableString_t_maxlen_set
    __swig_getmethods__["maxlen"] = _csnd.csCfgVariableString_t_maxlen_get
    if _newclass:maxlen = property(_csnd.csCfgVariableString_t_maxlen_get, _csnd.csCfgVariableString_t_maxlen_set)
    def __init__(self, *args):
        """__init__(self) -> csCfgVariableString_t"""
        _swig_setattr(self, csCfgVariableString_t, 'this', _csnd.new_csCfgVariableString_t(*args))
        _swig_setattr(self, csCfgVariableString_t, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_csCfgVariableString_t):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class csCfgVariableString_tPtr(csCfgVariableString_t):
    def __init__(self, this):
        _swig_setattr(self, csCfgVariableString_t, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, csCfgVariableString_t, 'thisown', 0)
        self.__class__ = csCfgVariableString_t
_csnd.csCfgVariableString_t_swigregister(csCfgVariableString_tPtr)

class csCfgVariable_t(_object):
    """Proxy of C++ csCfgVariable_t class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, csCfgVariable_t, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, csCfgVariable_t, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ csCfgVariable_t instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["h"] = _csnd.csCfgVariable_t_h_set
    __swig_getmethods__["h"] = _csnd.csCfgVariable_t_h_get
    if _newclass:h = property(_csnd.csCfgVariable_t_h_get, _csnd.csCfgVariable_t_h_set)
    __swig_setmethods__["i"] = _csnd.csCfgVariable_t_i_set
    __swig_getmethods__["i"] = _csnd.csCfgVariable_t_i_get
    if _newclass:i = property(_csnd.csCfgVariable_t_i_get, _csnd.csCfgVariable_t_i_set)
    __swig_setmethods__["b"] = _csnd.csCfgVariable_t_b_set
    __swig_getmethods__["b"] = _csnd.csCfgVariable_t_b_get
    if _newclass:b = property(_csnd.csCfgVariable_t_b_get, _csnd.csCfgVariable_t_b_set)
    __swig_setmethods__["f"] = _csnd.csCfgVariable_t_f_set
    __swig_getmethods__["f"] = _csnd.csCfgVariable_t_f_get
    if _newclass:f = property(_csnd.csCfgVariable_t_f_get, _csnd.csCfgVariable_t_f_set)
    __swig_setmethods__["d"] = _csnd.csCfgVariable_t_d_set
    __swig_getmethods__["d"] = _csnd.csCfgVariable_t_d_get
    if _newclass:d = property(_csnd.csCfgVariable_t_d_get, _csnd.csCfgVariable_t_d_set)
    __swig_setmethods__["m"] = _csnd.csCfgVariable_t_m_set
    __swig_getmethods__["m"] = _csnd.csCfgVariable_t_m_get
    if _newclass:m = property(_csnd.csCfgVariable_t_m_get, _csnd.csCfgVariable_t_m_set)
    __swig_setmethods__["s"] = _csnd.csCfgVariable_t_s_set
    __swig_getmethods__["s"] = _csnd.csCfgVariable_t_s_get
    if _newclass:s = property(_csnd.csCfgVariable_t_s_get, _csnd.csCfgVariable_t_s_set)
    def __init__(self, *args):
        """__init__(self) -> csCfgVariable_t"""
        _swig_setattr(self, csCfgVariable_t, 'this', _csnd.new_csCfgVariable_t(*args))
        _swig_setattr(self, csCfgVariable_t, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_csCfgVariable_t):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class csCfgVariable_tPtr(csCfgVariable_t):
    def __init__(self, this):
        _swig_setattr(self, csCfgVariable_t, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, csCfgVariable_t, 'thisown', 0)
        self.__class__ = csCfgVariable_t
_csnd.csCfgVariable_t_swigregister(csCfgVariable_tPtr)

CSOUNDCFG_INTEGER = _csnd.CSOUNDCFG_INTEGER
CSOUNDCFG_BOOLEAN = _csnd.CSOUNDCFG_BOOLEAN
CSOUNDCFG_FLOAT = _csnd.CSOUNDCFG_FLOAT
CSOUNDCFG_DOUBLE = _csnd.CSOUNDCFG_DOUBLE
CSOUNDCFG_MYFLT = _csnd.CSOUNDCFG_MYFLT
CSOUNDCFG_STRING = _csnd.CSOUNDCFG_STRING
CSOUNDCFG_POWOFTWO = _csnd.CSOUNDCFG_POWOFTWO
CSOUNDCFG_SUCCESS = _csnd.CSOUNDCFG_SUCCESS
CSOUNDCFG_INVALID_NAME = _csnd.CSOUNDCFG_INVALID_NAME
CSOUNDCFG_INVALID_TYPE = _csnd.CSOUNDCFG_INVALID_TYPE
CSOUNDCFG_INVALID_FLAG = _csnd.CSOUNDCFG_INVALID_FLAG
CSOUNDCFG_NULL_POINTER = _csnd.CSOUNDCFG_NULL_POINTER
CSOUNDCFG_TOO_HIGH = _csnd.CSOUNDCFG_TOO_HIGH
CSOUNDCFG_TOO_LOW = _csnd.CSOUNDCFG_TOO_LOW
CSOUNDCFG_NOT_POWOFTWO = _csnd.CSOUNDCFG_NOT_POWOFTWO
CSOUNDCFG_INVALID_BOOLEAN = _csnd.CSOUNDCFG_INVALID_BOOLEAN
CSOUNDCFG_MEMORY = _csnd.CSOUNDCFG_MEMORY
CSOUNDCFG_STRING_LENGTH = _csnd.CSOUNDCFG_STRING_LENGTH
CSOUNDCFG_LASTERROR = _csnd.CSOUNDCFG_LASTERROR

def csoundCreateConfigurationVariable(*args):
    """
    csoundCreateConfigurationVariable(CSOUND csound, char name, void p, int type, int flags, 
        void min, void max, char shortDesc, char longDesc) -> int
    """
    return _csnd.csoundCreateConfigurationVariable(*args)

def csoundSetConfigurationVariable(*args):
    """csoundSetConfigurationVariable(CSOUND csound, char name, void value) -> int"""
    return _csnd.csoundSetConfigurationVariable(*args)

def csoundParseConfigurationVariable(*args):
    """csoundParseConfigurationVariable(CSOUND csound, char name, char value) -> int"""
    return _csnd.csoundParseConfigurationVariable(*args)

def csoundQueryConfigurationVariable(*args):
    """csoundQueryConfigurationVariable(CSOUND csound, char name)"""
    return _csnd.csoundQueryConfigurationVariable(*args)

def csoundListConfigurationVariables(*args):
    """csoundListConfigurationVariables(CSOUND csound)"""
    return _csnd.csoundListConfigurationVariables(*args)

def csoundDeleteCfgVarList(*args):
    """csoundDeleteCfgVarList( lst)"""
    return _csnd.csoundDeleteCfgVarList(*args)

def csoundDeleteConfigurationVariable(*args):
    """csoundDeleteConfigurationVariable(CSOUND csound, char name) -> int"""
    return _csnd.csoundDeleteConfigurationVariable(*args)

def csoundCfgErrorCodeToString(*args):
    """csoundCfgErrorCodeToString(int errcode) -> char"""
    return _csnd.csoundCfgErrorCodeToString(*args)
CSOUNDMSG_DEFAULT = _csnd.CSOUNDMSG_DEFAULT
CSOUNDMSG_ERROR = _csnd.CSOUNDMSG_ERROR
CSOUNDMSG_ORCH = _csnd.CSOUNDMSG_ORCH
CSOUNDMSG_REALTIME = _csnd.CSOUNDMSG_REALTIME
CSOUNDMSG_WARNING = _csnd.CSOUNDMSG_WARNING
CSOUNDMSG_FG_BLACK = _csnd.CSOUNDMSG_FG_BLACK
CSOUNDMSG_FG_RED = _csnd.CSOUNDMSG_FG_RED
CSOUNDMSG_FG_GREEN = _csnd.CSOUNDMSG_FG_GREEN
CSOUNDMSG_FG_YELLOW = _csnd.CSOUNDMSG_FG_YELLOW
CSOUNDMSG_FG_BLUE = _csnd.CSOUNDMSG_FG_BLUE
CSOUNDMSG_FG_MAGENTA = _csnd.CSOUNDMSG_FG_MAGENTA
CSOUNDMSG_FG_CYAN = _csnd.CSOUNDMSG_FG_CYAN
CSOUNDMSG_FG_WHITE = _csnd.CSOUNDMSG_FG_WHITE
CSOUNDMSG_FG_BOLD = _csnd.CSOUNDMSG_FG_BOLD
CSOUNDMSG_FG_UNDERLINE = _csnd.CSOUNDMSG_FG_UNDERLINE
CSOUNDMSG_BG_BLACK = _csnd.CSOUNDMSG_BG_BLACK
CSOUNDMSG_BG_RED = _csnd.CSOUNDMSG_BG_RED
CSOUNDMSG_BG_GREEN = _csnd.CSOUNDMSG_BG_GREEN
CSOUNDMSG_BG_ORANGE = _csnd.CSOUNDMSG_BG_ORANGE
CSOUNDMSG_BG_BLUE = _csnd.CSOUNDMSG_BG_BLUE
CSOUNDMSG_BG_MAGENTA = _csnd.CSOUNDMSG_BG_MAGENTA
CSOUNDMSG_BG_CYAN = _csnd.CSOUNDMSG_BG_CYAN
CSOUNDMSG_BG_GREY = _csnd.CSOUNDMSG_BG_GREY
CSOUNDMSG_TYPE_MASK = _csnd.CSOUNDMSG_TYPE_MASK
CSOUNDMSG_FG_COLOR_MASK = _csnd.CSOUNDMSG_FG_COLOR_MASK
CSOUNDMSG_FG_ATTR_MASK = _csnd.CSOUNDMSG_FG_ATTR_MASK
CSOUNDMSG_BG_COLOR_MASK = _csnd.CSOUNDMSG_BG_COLOR_MASK
CS_PACKAGE_NAME = _csnd.CS_PACKAGE_NAME
CS_PACKAGE_STRING = _csnd.CS_PACKAGE_STRING
CS_PACKAGE_TARNAME = _csnd.CS_PACKAGE_TARNAME
CS_PACKAGE_VERSION = _csnd.CS_PACKAGE_VERSION
CS_VERSION = _csnd.CS_VERSION
CS_SUBVER = _csnd.CS_SUBVER
CS_PATCHLEVEL = _csnd.CS_PATCHLEVEL
CS_APIVERSION = _csnd.CS_APIVERSION
CS_APISUBVER = _csnd.CS_APISUBVER
class Csound(_object):
    """Proxy of C++ Csound class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Csound, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Csound, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ Csound instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def GetCsound(*args):
        """GetCsound(self) -> CSOUND"""
        return _csnd.Csound_GetCsound(*args)

    def PreCompile(*args):
        """PreCompile(self) -> int"""
        return _csnd.Csound_PreCompile(*args)

    def InitializeCscore(*args):
        """InitializeCscore(self, FILE insco, FILE outsco) -> int"""
        return _csnd.Csound_InitializeCscore(*args)

    def GetHostData(*args):
        """GetHostData(self) -> void"""
        return _csnd.Csound_GetHostData(*args)

    def SetHostData(*args):
        """SetHostData(self, void hostData)"""
        return _csnd.Csound_SetHostData(*args)

    def GetEnv(*args):
        """GetEnv(self, char name) -> char"""
        return _csnd.Csound_GetEnv(*args)

    def Compile(*args):
        """
        Compile(self, int argc, char argv) -> int
        Compile(self, char csdName) -> int
        Compile(self, char orcName, char scoName) -> int
        Compile(self, char arg1, char arg2, char arg3) -> int
        Compile(self, char arg1, char arg2, char arg3, char arg4) -> int
        Compile(self, char arg1, char arg2, char arg3, char arg4, char arg5) -> int
        """
        return _csnd.Csound_Compile(*args)

    def Perform(*args):
        """
        Perform(self) -> int
        Perform(self, int argc, char argv) -> int
        Perform(self, char csdName) -> int
        Perform(self, char orcName, char scoName) -> int
        Perform(self, char arg1, char arg2, char arg3) -> int
        Perform(self, char arg1, char arg2, char arg3, char arg4) -> int
        Perform(self, char arg1, char arg2, char arg3, char arg4, char arg5) -> int
        """
        return _csnd.Csound_Perform(*args)

    def PerformKsmps(*args):
        """PerformKsmps(self) -> int"""
        return _csnd.Csound_PerformKsmps(*args)

    def PerformKsmpsAbsolute(*args):
        """PerformKsmpsAbsolute(self) -> int"""
        return _csnd.Csound_PerformKsmpsAbsolute(*args)

    def PerformBuffer(*args):
        """PerformBuffer(self) -> int"""
        return _csnd.Csound_PerformBuffer(*args)

    def Stop(*args):
        """Stop(self)"""
        return _csnd.Csound_Stop(*args)

    def Cleanup(*args):
        """Cleanup(self) -> int"""
        return _csnd.Csound_Cleanup(*args)

    def Reset(*args):
        """Reset(self)"""
        return _csnd.Csound_Reset(*args)

    def GetSr(*args):
        """GetSr(self) -> float"""
        return _csnd.Csound_GetSr(*args)

    def GetKr(*args):
        """GetKr(self) -> float"""
        return _csnd.Csound_GetKr(*args)

    def GetKsmps(*args):
        """GetKsmps(self) -> int"""
        return _csnd.Csound_GetKsmps(*args)

    def GetNchnls(*args):
        """GetNchnls(self) -> int"""
        return _csnd.Csound_GetNchnls(*args)

    def Get0dBFS(*args):
        """Get0dBFS(self) -> float"""
        return _csnd.Csound_Get0dBFS(*args)

    def GetStrVarMaxLen(*args):
        """GetStrVarMaxLen(self) -> int"""
        return _csnd.Csound_GetStrVarMaxLen(*args)

    def GetSampleFormat(*args):
        """GetSampleFormat(self) -> int"""
        return _csnd.Csound_GetSampleFormat(*args)

    def GetSampleSize(*args):
        """GetSampleSize(self) -> int"""
        return _csnd.Csound_GetSampleSize(*args)

    def GetInputBufferSize(*args):
        """GetInputBufferSize(self) -> long"""
        return _csnd.Csound_GetInputBufferSize(*args)

    def GetOutputBufferSize(*args):
        """GetOutputBufferSize(self) -> long"""
        return _csnd.Csound_GetOutputBufferSize(*args)

    def GetInputBuffer(*args):
        """GetInputBuffer(self) -> float"""
        return _csnd.Csound_GetInputBuffer(*args)

    def GetOutputBuffer(*args):
        """GetOutputBuffer(self) -> float"""
        return _csnd.Csound_GetOutputBuffer(*args)

    def GetSpin(*args):
        """GetSpin(self) -> float"""
        return _csnd.Csound_GetSpin(*args)

    def GetSpout(*args):
        """GetSpout(self) -> float"""
        return _csnd.Csound_GetSpout(*args)

    def GetOutputFileName(*args):
        """GetOutputFileName(self) -> char"""
        return _csnd.Csound_GetOutputFileName(*args)

    def SetHostImplementedAudioIO(*args):
        """SetHostImplementedAudioIO(self, int state, int bufSize)"""
        return _csnd.Csound_SetHostImplementedAudioIO(*args)

    def GetScoreTime(*args):
        """GetScoreTime(self) -> double"""
        return _csnd.Csound_GetScoreTime(*args)

    def IsScorePending(*args):
        """IsScorePending(self) -> int"""
        return _csnd.Csound_IsScorePending(*args)

    def SetScorePending(*args):
        """SetScorePending(self, int pending)"""
        return _csnd.Csound_SetScorePending(*args)

    def GetScoreOffsetSeconds(*args):
        """GetScoreOffsetSeconds(self) -> float"""
        return _csnd.Csound_GetScoreOffsetSeconds(*args)

    def SetScoreOffsetSeconds(*args):
        """SetScoreOffsetSeconds(self, double time)"""
        return _csnd.Csound_SetScoreOffsetSeconds(*args)

    def RewindScore(*args):
        """RewindScore(self)"""
        return _csnd.Csound_RewindScore(*args)

    def ScoreSort(*args):
        """ScoreSort(self, FILE inFile, FILE outFile) -> int"""
        return _csnd.Csound_ScoreSort(*args)

    def ScoreExtract(*args):
        """ScoreExtract(self, FILE inFile, FILE outFile, FILE extractFile) -> int"""
        return _csnd.Csound_ScoreExtract(*args)

    def Message(*args):
        """Message(self, char format, v(...) ??)"""
        return _csnd.Csound_Message(*args)

    def MessageS(*args):
        """MessageS(self, int attr, char format, v(...) ??)"""
        return _csnd.Csound_MessageS(*args)

    def GetMessageLevel(*args):
        """GetMessageLevel(self) -> int"""
        return _csnd.Csound_GetMessageLevel(*args)

    def SetMessageLevel(*args):
        """SetMessageLevel(self, int messageLevel)"""
        return _csnd.Csound_SetMessageLevel(*args)

    def InputMessage(*args):
        """InputMessage(self, char message)"""
        return _csnd.Csound_InputMessage(*args)

    def KeyPress(*args):
        """KeyPress(self, char c)"""
        return _csnd.Csound_KeyPress(*args)

    def ScoreEvent(*args):
        """ScoreEvent(self, char type, float pFields, long numFields) -> int"""
        return _csnd.Csound_ScoreEvent(*args)

    def NewOpcodeList(*args):
        """NewOpcodeList(self, opcodeListEntry opcodelist) -> int"""
        return _csnd.Csound_NewOpcodeList(*args)

    def DisposeOpcodeList(*args):
        """DisposeOpcodeList(self, opcodeListEntry opcodelist)"""
        return _csnd.Csound_DisposeOpcodeList(*args)

    def AppendOpcode(*args):
        """
        AppendOpcode(self, char opname, int dsblksiz, int thread, char outypes, 
            char intypes, int iopadr, int kopadr, int aopadr) -> int
        """
        return _csnd.Csound_AppendOpcode(*args)

    def GetDebug(*args):
        """GetDebug(self) -> int"""
        return _csnd.Csound_GetDebug(*args)

    def SetDebug(*args):
        """SetDebug(self, int debug)"""
        return _csnd.Csound_SetDebug(*args)

    def TableLength(*args):
        """TableLength(self, int table) -> int"""
        return _csnd.Csound_TableLength(*args)

    def TableGet(*args):
        """TableGet(self, int table, int index) -> float"""
        return _csnd.Csound_TableGet(*args)

    def TableSet(*args):
        """TableSet(self, int table, int index, double value)"""
        return _csnd.Csound_TableSet(*args)

    def GetTable(*args):
        """GetTable(self, float tablePtr, int tableNum) -> int"""
        return _csnd.Csound_GetTable(*args)

    def CreateGlobalVariable(*args):
        """CreateGlobalVariable(self, char name, size_t nbytes) -> int"""
        return _csnd.Csound_CreateGlobalVariable(*args)

    def QueryGlobalVariable(*args):
        """QueryGlobalVariable(self, char name) -> void"""
        return _csnd.Csound_QueryGlobalVariable(*args)

    def QueryGlobalVariableNoCheck(*args):
        """QueryGlobalVariableNoCheck(self, char name) -> void"""
        return _csnd.Csound_QueryGlobalVariableNoCheck(*args)

    def DestroyGlobalVariable(*args):
        """DestroyGlobalVariable(self, char name) -> int"""
        return _csnd.Csound_DestroyGlobalVariable(*args)

    def GetRtRecordUserData(*args):
        """GetRtRecordUserData(self) -> void"""
        return _csnd.Csound_GetRtRecordUserData(*args)

    def GetRtPlayUserData(*args):
        """GetRtPlayUserData(self) -> void"""
        return _csnd.Csound_GetRtPlayUserData(*args)

    def RunUtility(*args):
        """RunUtility(self, char name, int argc, char argv) -> int"""
        return _csnd.Csound_RunUtility(*args)

    def ListUtilities(*args):
        """ListUtilities(self) -> char"""
        return _csnd.Csound_ListUtilities(*args)

    def DeleteUtilityList(*args):
        """DeleteUtilityList(self, char lst)"""
        return _csnd.Csound_DeleteUtilityList(*args)

    def GetUtilityDescription(*args):
        """GetUtilityDescription(self, char utilName) -> char"""
        return _csnd.Csound_GetUtilityDescription(*args)

    def GetChannelPtr(*args):
        """GetChannelPtr(self, float p, char name, int type) -> int"""
        return _csnd.Csound_GetChannelPtr(*args)

    def ListChannels(*args):
        """ListChannels(self,  lst) -> int"""
        return _csnd.Csound_ListChannels(*args)

    def DeleteChannelList(*args):
        """DeleteChannelList(self,  lst)"""
        return _csnd.Csound_DeleteChannelList(*args)

    def SetControlChannelParams(*args):
        """SetControlChannelParams(self, char name, int type, double dflt, double min, double max) -> int"""
        return _csnd.Csound_SetControlChannelParams(*args)

    def GetControlChannelParams(*args):
        """GetControlChannelParams(self, char name, float dflt, float min, float max) -> int"""
        return _csnd.Csound_GetControlChannelParams(*args)

    def SetChannel(*args):
        """
        SetChannel(self, char name, double value)
        SetChannel(self, char name, char value)
        """
        return _csnd.Csound_SetChannel(*args)

    def GetChannel(*args):
        """GetChannel(self, char name) -> float"""
        return _csnd.Csound_GetChannel(*args)

    def ChanIKSet(*args):
        """ChanIKSet(self, double value, int n) -> int"""
        return _csnd.Csound_ChanIKSet(*args)

    def ChanOKGet(*args):
        """ChanOKGet(self, float value, int n) -> int"""
        return _csnd.Csound_ChanOKGet(*args)

    def ChanIASet(*args):
        """ChanIASet(self, float value, int n) -> int"""
        return _csnd.Csound_ChanIASet(*args)

    def ChanOAGet(*args):
        """ChanOAGet(self, float value, int n) -> int"""
        return _csnd.Csound_ChanOAGet(*args)

    def PvsinSet(*args):
        """PvsinSet(self,  value, int n) -> int"""
        return _csnd.Csound_PvsinSet(*args)

    def PvsoutGet(*args):
        """PvsoutGet(self,  value, int n) -> int"""
        return _csnd.Csound_PvsoutGet(*args)

    def CreateConfigurationVariable(*args):
        """
        CreateConfigurationVariable(self, char name, void p, int type, int flags, void min, void max, 
            char shortDesc, char longDesc) -> int
        """
        return _csnd.Csound_CreateConfigurationVariable(*args)

    def SetConfigurationVariable(*args):
        """SetConfigurationVariable(self, char name, void value) -> int"""
        return _csnd.Csound_SetConfigurationVariable(*args)

    def ParseConfigurationVariable(*args):
        """ParseConfigurationVariable(self, char name, char value) -> int"""
        return _csnd.Csound_ParseConfigurationVariable(*args)

    def QueryConfigurationVariable(*args):
        """QueryConfigurationVariable(self, char name)"""
        return _csnd.Csound_QueryConfigurationVariable(*args)

    def ListConfigurationVariables(*args):
        """ListConfigurationVariables(self)"""
        return _csnd.Csound_ListConfigurationVariables(*args)

    def DeleteConfigurationVariable(*args):
        """DeleteConfigurationVariable(self, char name) -> int"""
        return _csnd.Csound_DeleteConfigurationVariable(*args)

    def SetChannelIOCallback(*args):
        """SetChannelIOCallback(self, CsoundChannelIOCallback_t func)"""
        return _csnd.Csound_SetChannelIOCallback(*args)

    def __init__(self, *args):
        """
        __init__(self) -> Csound
        __init__(self, void hostData) -> Csound
        """
        _swig_setattr(self, Csound, 'this', _csnd.new_Csound(*args))
        _swig_setattr(self, Csound, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_Csound):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass

    def EnableMessageBuffer(*args):
        """EnableMessageBuffer(self, int toStdOut)"""
        return _csnd.Csound_EnableMessageBuffer(*args)

    def GetFirstMessage(*args):
        """GetFirstMessage(self) -> char"""
        return _csnd.Csound_GetFirstMessage(*args)

    def GetFirstMessageAttr(*args):
        """GetFirstMessageAttr(self) -> int"""
        return _csnd.Csound_GetFirstMessageAttr(*args)

    def PopFirstMessage(*args):
        """PopFirstMessage(self)"""
        return _csnd.Csound_PopFirstMessage(*args)

    def GetMessageCnt(*args):
        """GetMessageCnt(self) -> int"""
        return _csnd.Csound_GetMessageCnt(*args)

    def DestroyMessageBuffer(*args):
        """DestroyMessageBuffer(self)"""
        return _csnd.Csound_DestroyMessageBuffer(*args)


class CsoundPtr(Csound):
    def __init__(self, this):
        _swig_setattr(self, Csound, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, Csound, 'thisown', 0)
        self.__class__ = Csound
_csnd.Csound_swigregister(CsoundPtr)

class CsoundThreadLock(_object):
    """Proxy of C++ CsoundThreadLock class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundThreadLock, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundThreadLock, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundThreadLock instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def Lock(*args):
        """
        Lock(self, size_t milliseconds) -> int
        Lock(self)
        """
        return _csnd.CsoundThreadLock_Lock(*args)

    def TryLock(*args):
        """TryLock(self) -> int"""
        return _csnd.CsoundThreadLock_TryLock(*args)

    def Unlock(*args):
        """Unlock(self)"""
        return _csnd.CsoundThreadLock_Unlock(*args)

    def __init__(self, *args):
        """
        __init__(self) -> CsoundThreadLock
        __init__(self, int locked) -> CsoundThreadLock
        """
        _swig_setattr(self, CsoundThreadLock, 'this', _csnd.new_CsoundThreadLock(*args))
        _swig_setattr(self, CsoundThreadLock, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundThreadLock):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundThreadLockPtr(CsoundThreadLock):
    def __init__(self, this):
        _swig_setattr(self, CsoundThreadLock, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundThreadLock, 'thisown', 0)
        self.__class__ = CsoundThreadLock
_csnd.CsoundThreadLock_swigregister(CsoundThreadLockPtr)

class CsoundMutex(_object):
    """Proxy of C++ CsoundMutex class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundMutex, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundMutex, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundMutex instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def Lock(*args):
        """Lock(self)"""
        return _csnd.CsoundMutex_Lock(*args)

    def TryLock(*args):
        """TryLock(self) -> int"""
        return _csnd.CsoundMutex_TryLock(*args)

    def Unlock(*args):
        """Unlock(self)"""
        return _csnd.CsoundMutex_Unlock(*args)

    def __init__(self, *args):
        """
        __init__(self) -> CsoundMutex
        __init__(self, int isRecursive) -> CsoundMutex
        """
        _swig_setattr(self, CsoundMutex, 'this', _csnd.new_CsoundMutex(*args))
        _swig_setattr(self, CsoundMutex, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundMutex):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundMutexPtr(CsoundMutex):
    def __init__(self, this):
        _swig_setattr(self, CsoundMutex, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundMutex, 'thisown', 0)
        self.__class__ = CsoundMutex
_csnd.CsoundMutex_swigregister(CsoundMutexPtr)

class CsoundRandMT(_object):
    """Proxy of C++ CsoundRandMT class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundRandMT, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundRandMT, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundRandMT instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def Random(*args):
        """Random(self) -> uint32_t"""
        return _csnd.CsoundRandMT_Random(*args)

    def Seed(*args):
        """
        Seed(self, uint32_t seedVal)
        Seed(self, uint32_t initKey, int keyLength)
        """
        return _csnd.CsoundRandMT_Seed(*args)

    def __init__(self, *args):
        """
        __init__(self) -> CsoundRandMT
        __init__(self, uint32_t seedVal) -> CsoundRandMT
        __init__(self, uint32_t initKey, int keyLength) -> CsoundRandMT
        """
        _swig_setattr(self, CsoundRandMT, 'this', _csnd.new_CsoundRandMT(*args))
        _swig_setattr(self, CsoundRandMT, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundRandMT):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundRandMTPtr(CsoundRandMT):
    def __init__(self, this):
        _swig_setattr(self, CsoundRandMT, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundRandMT, 'thisown', 0)
        self.__class__ = CsoundRandMT
_csnd.CsoundRandMT_swigregister(CsoundRandMTPtr)

class CsoundTimer(_object):
    """Proxy of C++ CsoundTimer class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundTimer, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundTimer, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundTimer instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def GetRealTime(*args):
        """GetRealTime(self) -> double"""
        return _csnd.CsoundTimer_GetRealTime(*args)

    def GetCPUTime(*args):
        """GetCPUTime(self) -> double"""
        return _csnd.CsoundTimer_GetCPUTime(*args)

    def Reset(*args):
        """Reset(self)"""
        return _csnd.CsoundTimer_Reset(*args)

    def __init__(self, *args):
        """__init__(self) -> CsoundTimer"""
        _swig_setattr(self, CsoundTimer, 'this', _csnd.new_CsoundTimer(*args))
        _swig_setattr(self, CsoundTimer, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundTimer):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundTimerPtr(CsoundTimer):
    def __init__(self, this):
        _swig_setattr(self, CsoundTimer, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundTimer, 'thisown', 0)
        self.__class__ = CsoundTimer
_csnd.CsoundTimer_swigregister(CsoundTimerPtr)


def sigcpy(*args):
    """sigcpy(float dest, float src, int size)"""
    return _csnd.sigcpy(*args)
class CsoundOpcodeList(_object):
    """Proxy of C++ CsoundOpcodeList class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundOpcodeList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundOpcodeList, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundOpcodeList instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def Count(*args):
        """Count(self) -> int"""
        return _csnd.CsoundOpcodeList_Count(*args)

    def Name(*args):
        """Name(self, int ndx) -> char"""
        return _csnd.CsoundOpcodeList_Name(*args)

    def OutTypes(*args):
        """OutTypes(self, int ndx) -> char"""
        return _csnd.CsoundOpcodeList_OutTypes(*args)

    def InTypes(*args):
        """InTypes(self, int ndx) -> char"""
        return _csnd.CsoundOpcodeList_InTypes(*args)

    def Clear(*args):
        """Clear(self)"""
        return _csnd.CsoundOpcodeList_Clear(*args)

    def __init__(self, *args):
        """
        __init__(self, CSOUND csound) -> CsoundOpcodeList
        __init__(self, Csound csound) -> CsoundOpcodeList
        """
        _swig_setattr(self, CsoundOpcodeList, 'this', _csnd.new_CsoundOpcodeList(*args))
        _swig_setattr(self, CsoundOpcodeList, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundOpcodeList):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundOpcodeListPtr(CsoundOpcodeList):
    def __init__(self, this):
        _swig_setattr(self, CsoundOpcodeList, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundOpcodeList, 'thisown', 0)
        self.__class__ = CsoundOpcodeList
_csnd.CsoundOpcodeList_swigregister(CsoundOpcodeListPtr)

class CsoundChannelList(_object):
    """Proxy of C++ CsoundChannelList class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundChannelList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundChannelList, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundChannelList instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def Count(*args):
        """Count(self) -> int"""
        return _csnd.CsoundChannelList_Count(*args)

    def Name(*args):
        """Name(self, int ndx) -> char"""
        return _csnd.CsoundChannelList_Name(*args)

    def Type(*args):
        """Type(self, int ndx) -> int"""
        return _csnd.CsoundChannelList_Type(*args)

    def IsControlChannel(*args):
        """IsControlChannel(self, int ndx) -> int"""
        return _csnd.CsoundChannelList_IsControlChannel(*args)

    def IsAudioChannel(*args):
        """IsAudioChannel(self, int ndx) -> int"""
        return _csnd.CsoundChannelList_IsAudioChannel(*args)

    def IsStringChannel(*args):
        """IsStringChannel(self, int ndx) -> int"""
        return _csnd.CsoundChannelList_IsStringChannel(*args)

    def IsInputChannel(*args):
        """IsInputChannel(self, int ndx) -> int"""
        return _csnd.CsoundChannelList_IsInputChannel(*args)

    def IsOutputChannel(*args):
        """IsOutputChannel(self, int ndx) -> int"""
        return _csnd.CsoundChannelList_IsOutputChannel(*args)

    def SubType(*args):
        """SubType(self, int ndx) -> int"""
        return _csnd.CsoundChannelList_SubType(*args)

    def DefaultValue(*args):
        """DefaultValue(self, int ndx) -> double"""
        return _csnd.CsoundChannelList_DefaultValue(*args)

    def MinValue(*args):
        """MinValue(self, int ndx) -> double"""
        return _csnd.CsoundChannelList_MinValue(*args)

    def MaxValue(*args):
        """MaxValue(self, int ndx) -> double"""
        return _csnd.CsoundChannelList_MaxValue(*args)

    def Clear(*args):
        """Clear(self)"""
        return _csnd.CsoundChannelList_Clear(*args)

    def __init__(self, *args):
        """
        __init__(self, CSOUND csound) -> CsoundChannelList
        __init__(self, Csound csound) -> CsoundChannelList
        """
        _swig_setattr(self, CsoundChannelList, 'this', _csnd.new_CsoundChannelList(*args))
        _swig_setattr(self, CsoundChannelList, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundChannelList):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundChannelListPtr(CsoundChannelList):
    def __init__(self, this):
        _swig_setattr(self, CsoundChannelList, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundChannelList, 'thisown', 0)
        self.__class__ = CsoundChannelList
_csnd.CsoundChannelList_swigregister(CsoundChannelListPtr)

class CsoundUtilityList(_object):
    """Proxy of C++ CsoundUtilityList class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundUtilityList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundUtilityList, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundUtilityList instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def Count(*args):
        """Count(self) -> int"""
        return _csnd.CsoundUtilityList_Count(*args)

    def Name(*args):
        """Name(self, int ndx) -> char"""
        return _csnd.CsoundUtilityList_Name(*args)

    def Clear(*args):
        """Clear(self)"""
        return _csnd.CsoundUtilityList_Clear(*args)

    def __init__(self, *args):
        """
        __init__(self, CSOUND csound) -> CsoundUtilityList
        __init__(self, Csound csound) -> CsoundUtilityList
        """
        _swig_setattr(self, CsoundUtilityList, 'this', _csnd.new_CsoundUtilityList(*args))
        _swig_setattr(self, CsoundUtilityList, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundUtilityList):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundUtilityListPtr(CsoundUtilityList):
    def __init__(self, this):
        _swig_setattr(self, CsoundUtilityList, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundUtilityList, 'thisown', 0)
        self.__class__ = CsoundUtilityList
_csnd.CsoundUtilityList_swigregister(CsoundUtilityListPtr)

class CsoundMYFLTArray(_object):
    """Proxy of C++ CsoundMYFLTArray class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundMYFLTArray, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundMYFLTArray, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundMYFLTArray instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def GetPtr(*args):
        """
        GetPtr(self) -> float
        GetPtr(self, int ndx) -> float
        """
        return _csnd.CsoundMYFLTArray_GetPtr(*args)

    def SetPtr(*args):
        """SetPtr(self, float ptr)"""
        return _csnd.CsoundMYFLTArray_SetPtr(*args)

    def SetValue(*args):
        """SetValue(self, int ndx, double value)"""
        return _csnd.CsoundMYFLTArray_SetValue(*args)

    def GetValue(*args):
        """GetValue(self, int ndx) -> double"""
        return _csnd.CsoundMYFLTArray_GetValue(*args)

    def SetValues(*args):
        """
        SetValues(self, int ndx, double v0, double v1)
        SetValues(self, int ndx, double v0, double v1, double v2)
        SetValues(self, int ndx, double v0, double v1, double v2, double v3)
        SetValues(self, int ndx, double v0, double v1, double v2, double v3, 
            double v4)
        SetValues(self, int ndx, double v0, double v1, double v2, double v3, 
            double v4, double v5)
        SetValues(self, int ndx, double v0, double v1, double v2, double v3, 
            double v4, double v5, double v6)
        SetValues(self, int ndx, double v0, double v1, double v2, double v3, 
            double v4, double v5, double v6, double v7)
        SetValues(self, int ndx, double v0, double v1, double v2, double v3, 
            double v4, double v5, double v6, double v7, 
            double v8)
        SetValues(self, int ndx, double v0, double v1, double v2, double v3, 
            double v4, double v5, double v6, double v7, 
            double v8, double v9)
        SetValues(self, int ndx, int n, float src)
        """
        return _csnd.CsoundMYFLTArray_SetValues(*args)

    def GetValues(*args):
        """GetValues(self, float dst, int ndx, int n)"""
        return _csnd.CsoundMYFLTArray_GetValues(*args)

    def SetStringValue(*args):
        """SetStringValue(self, char s, int maxLen)"""
        return _csnd.CsoundMYFLTArray_SetStringValue(*args)

    def GetStringValue(*args):
        """GetStringValue(self) -> char"""
        return _csnd.CsoundMYFLTArray_GetStringValue(*args)

    def Clear(*args):
        """Clear(self)"""
        return _csnd.CsoundMYFLTArray_Clear(*args)

    def __init__(self, *args):
        """
        __init__(self) -> CsoundMYFLTArray
        __init__(self, int n) -> CsoundMYFLTArray
        """
        _swig_setattr(self, CsoundMYFLTArray, 'this', _csnd.new_CsoundMYFLTArray(*args))
        _swig_setattr(self, CsoundMYFLTArray, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundMYFLTArray):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundMYFLTArrayPtr(CsoundMYFLTArray):
    def __init__(self, this):
        _swig_setattr(self, CsoundMYFLTArray, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundMYFLTArray, 'thisown', 0)
        self.__class__ = CsoundMYFLTArray
_csnd.CsoundMYFLTArray_swigregister(CsoundMYFLTArrayPtr)

class CsoundArgVList(_object):
    """Proxy of C++ CsoundArgVList class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundArgVList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundArgVList, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundArgVList instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def argc(*args):
        """argc(self) -> int"""
        return _csnd.CsoundArgVList_argc(*args)

    def argv(*args):
        """
        argv(self) -> char
        argv(self, int ndx) -> char
        """
        return _csnd.CsoundArgVList_argv(*args)

    def Insert(*args):
        """Insert(self, int ndx, char s)"""
        return _csnd.CsoundArgVList_Insert(*args)

    def Append(*args):
        """Append(self, char s)"""
        return _csnd.CsoundArgVList_Append(*args)

    def Clear(*args):
        """Clear(self)"""
        return _csnd.CsoundArgVList_Clear(*args)

    def __init__(self, *args):
        """__init__(self) -> CsoundArgVList"""
        _swig_setattr(self, CsoundArgVList, 'this', _csnd.new_CsoundArgVList(*args))
        _swig_setattr(self, CsoundArgVList, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundArgVList):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundArgVListPtr(CsoundArgVList):
    def __init__(self, this):
        _swig_setattr(self, CsoundArgVList, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundArgVList, 'thisown', 0)
        self.__class__ = CsoundArgVList
_csnd.CsoundArgVList_swigregister(CsoundArgVListPtr)

class CsoundCallbackWrapper(_object):
    """Proxy of C++ CsoundCallbackWrapper class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundCallbackWrapper, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundCallbackWrapper, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundCallbackWrapper instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def MessageCallback(*args):
        """MessageCallback(self, int attr, char msg)"""
        return _csnd.CsoundCallbackWrapper_MessageCallback(*args)

    def InputValueCallback(*args):
        """InputValueCallback(self, char chnName) -> double"""
        return _csnd.CsoundCallbackWrapper_InputValueCallback(*args)

    def OutputValueCallback(*args):
        """OutputValueCallback(self, char chnName, double value)"""
        return _csnd.CsoundCallbackWrapper_OutputValueCallback(*args)

    def YieldCallback(*args):
        """YieldCallback(self) -> int"""
        return _csnd.CsoundCallbackWrapper_YieldCallback(*args)

    def MidiInputCallback(*args):
        """MidiInputCallback(self, CsoundMidiInputBuffer p)"""
        return _csnd.CsoundCallbackWrapper_MidiInputCallback(*args)

    def MidiOutputCallback(*args):
        """MidiOutputCallback(self, CsoundMidiOutputBuffer p)"""
        return _csnd.CsoundCallbackWrapper_MidiOutputCallback(*args)

    def ControlChannelInputCallback(*args):
        """ControlChannelInputCallback(self, char chnName) -> double"""
        return _csnd.CsoundCallbackWrapper_ControlChannelInputCallback(*args)

    def ControlChannelOutputCallback(*args):
        """ControlChannelOutputCallback(self, char chnName, double value)"""
        return _csnd.CsoundCallbackWrapper_ControlChannelOutputCallback(*args)

    def StringChannelInputCallback(*args):
        """StringChannelInputCallback(self, char chnName) -> char"""
        return _csnd.CsoundCallbackWrapper_StringChannelInputCallback(*args)

    def StringChannelOutputCallback(*args):
        """StringChannelOutputCallback(self, char chnName, char value)"""
        return _csnd.CsoundCallbackWrapper_StringChannelOutputCallback(*args)

    def SetMessageCallback(*args):
        """SetMessageCallback(self)"""
        return _csnd.CsoundCallbackWrapper_SetMessageCallback(*args)

    def SetInputValueCallback(*args):
        """SetInputValueCallback(self)"""
        return _csnd.CsoundCallbackWrapper_SetInputValueCallback(*args)

    def SetOutputValueCallback(*args):
        """SetOutputValueCallback(self)"""
        return _csnd.CsoundCallbackWrapper_SetOutputValueCallback(*args)

    def SetYieldCallback(*args):
        """SetYieldCallback(self)"""
        return _csnd.CsoundCallbackWrapper_SetYieldCallback(*args)

    def SetMidiInputCallback(*args):
        """SetMidiInputCallback(self, CsoundArgVList argv)"""
        return _csnd.CsoundCallbackWrapper_SetMidiInputCallback(*args)

    def SetMidiOutputCallback(*args):
        """SetMidiOutputCallback(self, CsoundArgVList argv)"""
        return _csnd.CsoundCallbackWrapper_SetMidiOutputCallback(*args)

    def SetChannelIOCallbacks(*args):
        """SetChannelIOCallbacks(self)"""
        return _csnd.CsoundCallbackWrapper_SetChannelIOCallbacks(*args)

    def GetCsound(*args):
        """GetCsound(self) -> CSOUND"""
        return _csnd.CsoundCallbackWrapper_GetCsound(*args)

    def CharPtrToString(*args):
        """CharPtrToString(char s) -> char"""
        return _csnd.CsoundCallbackWrapper_CharPtrToString(*args)

    if _newclass:CharPtrToString = staticmethod(CharPtrToString)
    __swig_getmethods__["CharPtrToString"] = lambda x: CharPtrToString
    def __init__(self, *args):
        """
        __init__(self, Csound csound) -> CsoundCallbackWrapper
        __init__(self, CSOUND csound) -> CsoundCallbackWrapper
        """
        _swig_setattr(self, CsoundCallbackWrapper, 'this', _csnd.new_CsoundCallbackWrapper(*args))
        _swig_setattr(self, CsoundCallbackWrapper, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundCallbackWrapper):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class CsoundCallbackWrapperPtr(CsoundCallbackWrapper):
    def __init__(self, this):
        _swig_setattr(self, CsoundCallbackWrapper, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundCallbackWrapper, 'thisown', 0)
        self.__class__ = CsoundCallbackWrapper
_csnd.CsoundCallbackWrapper_swigregister(CsoundCallbackWrapperPtr)

def CsoundCallbackWrapper_CharPtrToString(*args):
    """CsoundCallbackWrapper_CharPtrToString(char s) -> char"""
    return _csnd.CsoundCallbackWrapper_CharPtrToString(*args)

class CsoundMidiInputBuffer(_object):
    """Proxy of C++ CsoundMidiInputBuffer class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundMidiInputBuffer, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundMidiInputBuffer, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundMidiInputBuffer instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        """__init__(self, unsigned char buf, int bufSize) -> CsoundMidiInputBuffer"""
        _swig_setattr(self, CsoundMidiInputBuffer, 'this', _csnd.new_CsoundMidiInputBuffer(*args))
        _swig_setattr(self, CsoundMidiInputBuffer, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundMidiInputBuffer):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass

    def SendMessage(*args):
        """
        SendMessage(self, int msg)
        SendMessage(self, int status, int channel, int data1, int data2)
        """
        return _csnd.CsoundMidiInputBuffer_SendMessage(*args)

    def SendNoteOn(*args):
        """SendNoteOn(self, int channel, int key, int velocity)"""
        return _csnd.CsoundMidiInputBuffer_SendNoteOn(*args)

    def SendNoteOff(*args):
        """
        SendNoteOff(self, int channel, int key, int velocity)
        SendNoteOff(self, int channel, int key)
        """
        return _csnd.CsoundMidiInputBuffer_SendNoteOff(*args)

    def SendPolyphonicPressure(*args):
        """SendPolyphonicPressure(self, int channel, int key, int value)"""
        return _csnd.CsoundMidiInputBuffer_SendPolyphonicPressure(*args)

    def SendControlChange(*args):
        """SendControlChange(self, int channel, int ctl, int value)"""
        return _csnd.CsoundMidiInputBuffer_SendControlChange(*args)

    def SendProgramChange(*args):
        """SendProgramChange(self, int channel, int pgm)"""
        return _csnd.CsoundMidiInputBuffer_SendProgramChange(*args)

    def SendChannelPressure(*args):
        """SendChannelPressure(self, int channel, int value)"""
        return _csnd.CsoundMidiInputBuffer_SendChannelPressure(*args)

    def SendPitchBend(*args):
        """SendPitchBend(self, int channel, int value)"""
        return _csnd.CsoundMidiInputBuffer_SendPitchBend(*args)


class CsoundMidiInputBufferPtr(CsoundMidiInputBuffer):
    def __init__(self, this):
        _swig_setattr(self, CsoundMidiInputBuffer, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundMidiInputBuffer, 'thisown', 0)
        self.__class__ = CsoundMidiInputBuffer
_csnd.CsoundMidiInputBuffer_swigregister(CsoundMidiInputBufferPtr)

class CsoundMidiInputStream(CsoundMidiInputBuffer):
    """Proxy of C++ CsoundMidiInputStream class"""
    __swig_setmethods__ = {}
    for _s in [CsoundMidiInputBuffer]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundMidiInputStream, name, value)
    __swig_getmethods__ = {}
    for _s in [CsoundMidiInputBuffer]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundMidiInputStream, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundMidiInputStream instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        """
        __init__(self, CSOUND csound) -> CsoundMidiInputStream
        __init__(self, Csound csound) -> CsoundMidiInputStream
        """
        _swig_setattr(self, CsoundMidiInputStream, 'this', _csnd.new_CsoundMidiInputStream(*args))
        _swig_setattr(self, CsoundMidiInputStream, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundMidiInputStream):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass

    def EnableMidiInput(*args):
        """EnableMidiInput(self, CsoundArgVList argv)"""
        return _csnd.CsoundMidiInputStream_EnableMidiInput(*args)


class CsoundMidiInputStreamPtr(CsoundMidiInputStream):
    def __init__(self, this):
        _swig_setattr(self, CsoundMidiInputStream, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundMidiInputStream, 'thisown', 0)
        self.__class__ = CsoundMidiInputStream
_csnd.CsoundMidiInputStream_swigregister(CsoundMidiInputStreamPtr)

class CsoundMidiOutputBuffer(_object):
    """Proxy of C++ CsoundMidiOutputBuffer class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundMidiOutputBuffer, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundMidiOutputBuffer, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundMidiOutputBuffer instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        """__init__(self, unsigned char buf, int bufSize) -> CsoundMidiOutputBuffer"""
        _swig_setattr(self, CsoundMidiOutputBuffer, 'this', _csnd.new_CsoundMidiOutputBuffer(*args))
        _swig_setattr(self, CsoundMidiOutputBuffer, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundMidiOutputBuffer):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass

    def PopMessage(*args):
        """PopMessage(self) -> int"""
        return _csnd.CsoundMidiOutputBuffer_PopMessage(*args)

    def GetStatus(*args):
        """GetStatus(self) -> int"""
        return _csnd.CsoundMidiOutputBuffer_GetStatus(*args)

    def GetChannel(*args):
        """GetChannel(self) -> int"""
        return _csnd.CsoundMidiOutputBuffer_GetChannel(*args)

    def GetData1(*args):
        """GetData1(self) -> int"""
        return _csnd.CsoundMidiOutputBuffer_GetData1(*args)

    def GetData2(*args):
        """GetData2(self) -> int"""
        return _csnd.CsoundMidiOutputBuffer_GetData2(*args)


class CsoundMidiOutputBufferPtr(CsoundMidiOutputBuffer):
    def __init__(self, this):
        _swig_setattr(self, CsoundMidiOutputBuffer, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundMidiOutputBuffer, 'thisown', 0)
        self.__class__ = CsoundMidiOutputBuffer
_csnd.CsoundMidiOutputBuffer_swigregister(CsoundMidiOutputBufferPtr)

class CsoundMidiOutputStream(CsoundMidiOutputBuffer):
    """Proxy of C++ CsoundMidiOutputStream class"""
    __swig_setmethods__ = {}
    for _s in [CsoundMidiOutputBuffer]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundMidiOutputStream, name, value)
    __swig_getmethods__ = {}
    for _s in [CsoundMidiOutputBuffer]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundMidiOutputStream, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundMidiOutputStream instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        """
        __init__(self, CSOUND csound) -> CsoundMidiOutputStream
        __init__(self, Csound csound) -> CsoundMidiOutputStream
        """
        _swig_setattr(self, CsoundMidiOutputStream, 'this', _csnd.new_CsoundMidiOutputStream(*args))
        _swig_setattr(self, CsoundMidiOutputStream, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundMidiOutputStream):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass

    def EnableMidiOutput(*args):
        """EnableMidiOutput(self, CsoundArgVList argv)"""
        return _csnd.CsoundMidiOutputStream_EnableMidiOutput(*args)


class CsoundMidiOutputStreamPtr(CsoundMidiOutputStream):
    def __init__(self, this):
        _swig_setattr(self, CsoundMidiOutputStream, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundMidiOutputStream, 'thisown', 0)
        self.__class__ = CsoundMidiOutputStream
_csnd.CsoundMidiOutputStream_swigregister(CsoundMidiOutputStreamPtr)

class pycallbackdata(_object):
    """Proxy of C++ pycallbackdata class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, pycallbackdata, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, pycallbackdata, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ pycallbackdata instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["func"] = _csnd.pycallbackdata_func_set
    __swig_getmethods__["func"] = _csnd.pycallbackdata_func_get
    if _newclass:func = property(_csnd.pycallbackdata_func_get, _csnd.pycallbackdata_func_set)
    __swig_setmethods__["data"] = _csnd.pycallbackdata_data_set
    __swig_getmethods__["data"] = _csnd.pycallbackdata_data_get
    if _newclass:data = property(_csnd.pycallbackdata_data_get, _csnd.pycallbackdata_data_set)
    def __init__(self, *args):
        """__init__(self) -> pycallbackdata"""
        _swig_setattr(self, pycallbackdata, 'this', _csnd.new_pycallbackdata(*args))
        _swig_setattr(self, pycallbackdata, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_pycallbackdata):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class pycallbackdataPtr(pycallbackdata):
    def __init__(self, this):
        _swig_setattr(self, pycallbackdata, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, pycallbackdata, 'thisown', 0)
        self.__class__ = pycallbackdata
_csnd.pycallbackdata_swigregister(pycallbackdataPtr)

class CsoundPerformanceThread(_object):
    """Proxy of C++ CsoundPerformanceThread class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CsoundPerformanceThread, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CsoundPerformanceThread, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CsoundPerformanceThread instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    __swig_setmethods__["_tstate"] = _csnd.CsoundPerformanceThread__tstate_set
    __swig_getmethods__["_tstate"] = _csnd.CsoundPerformanceThread__tstate_get
    if _newclass:_tstate = property(_csnd.CsoundPerformanceThread__tstate_get, _csnd.CsoundPerformanceThread__tstate_set)
    __swig_setmethods__["pydata"] = _csnd.CsoundPerformanceThread_pydata_set
    __swig_getmethods__["pydata"] = _csnd.CsoundPerformanceThread_pydata_get
    if _newclass:pydata = property(_csnd.CsoundPerformanceThread_pydata_get, _csnd.CsoundPerformanceThread_pydata_set)
    def GetProcessCallback(*args):
        """GetProcessCallback(self) -> void"""
        return _csnd.CsoundPerformanceThread_GetProcessCallback(*args)

    def GetCsound(*args):
        """GetCsound(self) -> CSOUND"""
        return _csnd.CsoundPerformanceThread_GetCsound(*args)

    def GetStatus(*args):
        """GetStatus(self) -> int"""
        return _csnd.CsoundPerformanceThread_GetStatus(*args)

    def Play(*args):
        """Play(self)"""
        return _csnd.CsoundPerformanceThread_Play(*args)

    def Pause(*args):
        """Pause(self)"""
        return _csnd.CsoundPerformanceThread_Pause(*args)

    def TogglePause(*args):
        """TogglePause(self)"""
        return _csnd.CsoundPerformanceThread_TogglePause(*args)

    def Stop(*args):
        """Stop(self)"""
        return _csnd.CsoundPerformanceThread_Stop(*args)

    def ScoreEvent(*args):
        """ScoreEvent(self, int absp2mode, char opcod, int pcnt, float p)"""
        return _csnd.CsoundPerformanceThread_ScoreEvent(*args)

    def InputMessage(*args):
        """InputMessage(self, char s)"""
        return _csnd.CsoundPerformanceThread_InputMessage(*args)

    def SetScoreOffsetSeconds(*args):
        """SetScoreOffsetSeconds(self, double timeVal)"""
        return _csnd.CsoundPerformanceThread_SetScoreOffsetSeconds(*args)

    def Join(*args):
        """Join(self) -> int"""
        return _csnd.CsoundPerformanceThread_Join(*args)

    def FlushMessageQueue(*args):
        """FlushMessageQueue(self)"""
        return _csnd.CsoundPerformanceThread_FlushMessageQueue(*args)

    def __init__(self, *args):
        """
        __init__(self, Csound ??) -> CsoundPerformanceThread
        __init__(self, CSOUND ??) -> CsoundPerformanceThread
        """
        _swig_setattr(self, CsoundPerformanceThread, 'this', _csnd.new_CsoundPerformanceThread(*args))
        _swig_setattr(self, CsoundPerformanceThread, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CsoundPerformanceThread):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass

    def SetProcessCallback(*args):
        """SetProcessCallback(self, PyObject pyfunc, PyObject p)"""
        return _csnd.CsoundPerformanceThread_SetProcessCallback(*args)


class CsoundPerformanceThreadPtr(CsoundPerformanceThread):
    def __init__(self, this):
        _swig_setattr(self, CsoundPerformanceThread, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CsoundPerformanceThread, 'thisown', 0)
        self.__class__ = CsoundPerformanceThread
_csnd.CsoundPerformanceThread_swigregister(CsoundPerformanceThreadPtr)

class MyfltVector(_object):
    """Proxy of C++ MyfltVector class"""
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, MyfltVector, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, MyfltVector, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ std::vector<float > instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def empty(*args):
        """empty(self) -> bool"""
        return _csnd.MyfltVector_empty(*args)

    def size(*args):
        """size(self) -> size_type"""
        return _csnd.MyfltVector_size(*args)

    def clear(*args):
        """clear(self)"""
        return _csnd.MyfltVector_clear(*args)

    def swap(*args):
        """swap(self, MyfltVector v)"""
        return _csnd.MyfltVector_swap(*args)

    def get_allocator(*args):
        """get_allocator(self) -> allocator_type"""
        return _csnd.MyfltVector_get_allocator(*args)

    def pop_back(*args):
        """pop_back(self)"""
        return _csnd.MyfltVector_pop_back(*args)

    def __init__(self, *args):
        """
        __init__(self) -> MyfltVector
        __init__(self, MyfltVector ??) -> MyfltVector
        __init__(self, size_type size) -> MyfltVector
        __init__(self, size_type size, value_type value) -> MyfltVector
        """
        _swig_setattr(self, MyfltVector, 'this', _csnd.new_MyfltVector(*args))
        _swig_setattr(self, MyfltVector, 'thisown', 1)
    def push_back(*args):
        """push_back(self, value_type x)"""
        return _csnd.MyfltVector_push_back(*args)

    def front(*args):
        """front(self) -> value_type"""
        return _csnd.MyfltVector_front(*args)

    def back(*args):
        """back(self) -> value_type"""
        return _csnd.MyfltVector_back(*args)

    def assign(*args):
        """assign(self, size_type n, value_type x)"""
        return _csnd.MyfltVector_assign(*args)

    def resize(*args):
        """
        resize(self, size_type new_size)
        resize(self, size_type new_size, value_type x)
        """
        return _csnd.MyfltVector_resize(*args)

    def reserve(*args):
        """reserve(self, size_type n)"""
        return _csnd.MyfltVector_reserve(*args)

    def capacity(*args):
        """capacity(self) -> size_type"""
        return _csnd.MyfltVector_capacity(*args)

    def __nonzero__(*args):
        """__nonzero__(self) -> bool"""
        return _csnd.MyfltVector___nonzero__(*args)

    def __len__(*args):
        """__len__(self) -> size_type"""
        return _csnd.MyfltVector___len__(*args)

    def pop(*args):
        """pop(self) -> value_type"""
        return _csnd.MyfltVector_pop(*args)

    def __getslice__(*args):
        """__getslice__(self, difference_type i, difference_type j) -> MyfltVector"""
        return _csnd.MyfltVector___getslice__(*args)

    def __setslice__(*args):
        """__setslice__(self, difference_type i, difference_type j, MyfltVector v)"""
        return _csnd.MyfltVector___setslice__(*args)

    def __delslice__(*args):
        """__delslice__(self, difference_type i, difference_type j)"""
        return _csnd.MyfltVector___delslice__(*args)

    def __delitem__(*args):
        """__delitem__(self, difference_type i)"""
        return _csnd.MyfltVector___delitem__(*args)

    def __getitem__(*args):
        """__getitem__(self, difference_type i) -> value_type"""
        return _csnd.MyfltVector___getitem__(*args)

    def __setitem__(*args):
        """__setitem__(self, difference_type i, value_type x)"""
        return _csnd.MyfltVector___setitem__(*args)

    def append(*args):
        """append(self, value_type x)"""
        return _csnd.MyfltVector_append(*args)

    def __del__(self, destroy=_csnd.delete_MyfltVector):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass


class MyfltVectorPtr(MyfltVector):
    def __init__(self, this):
        _swig_setattr(self, MyfltVector, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, MyfltVector, 'thisown', 0)
        self.__class__ = MyfltVector
_csnd.MyfltVector_swigregister(MyfltVectorPtr)

class CppSound(Csound):
    """Proxy of C++ CppSound class"""
    __swig_setmethods__ = {}
    for _s in [Csound]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, CppSound, name, value)
    __swig_getmethods__ = {}
    for _s in [Csound]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, CppSound, name)
    def __repr__(self):
        return "<%s.%s; proxy of C++ CppSound instance at %s>" % (self.__class__.__module__, self.__class__.__name__, self.this,)
    def __init__(self, *args):
        """__init__(self) -> CppSound"""
        _swig_setattr(self, CppSound, 'this', _csnd.new_CppSound(*args))
        _swig_setattr(self, CppSound, 'thisown', 1)
    def __del__(self, destroy=_csnd.delete_CppSound):
        """__del__(self)"""
        try:
            if self.thisown: destroy(self)
        except: pass

    def getCsound(*args):
        """getCsound(self) -> CSOUND"""
        return _csnd.CppSound_getCsound(*args)

    def getThis(*args):
        """getThis(self) -> long"""
        return _csnd.CppSound_getThis(*args)

    def getCsoundFile(*args):
        """getCsoundFile(self) -> CsoundFile"""
        return _csnd.CppSound_getCsoundFile(*args)

    def compile(*args):
        """
        compile(self, int argc, char argv) -> int
        compile(self) -> int
        """
        return _csnd.CppSound_compile(*args)

    def getSpoutSize(*args):
        """getSpoutSize(self) -> size_t"""
        return _csnd.CppSound_getSpoutSize(*args)

    def getOutputSoundfileName(*args):
        """getOutputSoundfileName(self) -> string"""
        return _csnd.CppSound_getOutputSoundfileName(*args)

    def perform(*args):
        """
        perform(self, int argc, char argv) -> int
        perform(self) -> int
        """
        return _csnd.CppSound_perform(*args)

    def performKsmps(*args):
        """performKsmps(self, bool absolute) -> int"""
        return _csnd.CppSound_performKsmps(*args)

    def cleanup(*args):
        """cleanup(self)"""
        return _csnd.CppSound_cleanup(*args)

    def inputMessage(*args):
        """inputMessage(self, char istatement)"""
        return _csnd.CppSound_inputMessage(*args)

    def write(*args):
        """write(self, char text)"""
        return _csnd.CppSound_write(*args)

    def getIsCompiled(*args):
        """getIsCompiled(self) -> bool"""
        return _csnd.CppSound_getIsCompiled(*args)

    def setIsPerforming(*args):
        """setIsPerforming(self, bool isPerforming)"""
        return _csnd.CppSound_setIsPerforming(*args)

    def getIsPerforming(*args):
        """getIsPerforming(self) -> bool"""
        return _csnd.CppSound_getIsPerforming(*args)

    def getIsGo(*args):
        """getIsGo(self) -> bool"""
        return _csnd.CppSound_getIsGo(*args)

    def stop(*args):
        """stop(self)"""
        return _csnd.CppSound_stop(*args)

    def setPythonMessageCallback(*args):
        """setPythonMessageCallback(self)"""
        return _csnd.CppSound_setPythonMessageCallback(*args)


class CppSoundPtr(CppSound):
    def __init__(self, this):
        _swig_setattr(self, CppSound, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CppSound, 'thisown', 0)
        self.__class__ = CppSound
_csnd.CppSound_swigregister(CppSoundPtr)



