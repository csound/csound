tar cf $1.tar Csound5.mpkg CsoundApps.pkg CsoundLib.pkg SupportLibs.pkg readme.rtf
gzip $1.tar



